# DKKF Client 0.2.0 — Minecraft 26.3 Fabric

Neon Edition의 기본 제작 기준을 **Minecraft 26.3 / Fabric Loader 0.20.1 / Fabric API 0.166.2+26.3**으로 변경했습니다. 게임에는 **Java 25 이상**이 필요합니다. 현재 머신에서는 Java 26으로 빌드·설치 검증했고, 코어 바이트코드는 Java 25를 대상으로 생성했습니다.

## 실행 파일

- 설치 프로그램: `release/DKKF-Client-0.2.0-Setup.exe`
- 설치 없이 실행: `release/win-unpacked/DKKF Client.exe` (폴더의 모든 파일 필요)
- HUD JAR: `assets/client-core/dkkf-core-fabric-26.3-0.2.0.jar`
- 전체 소스: `release/DKKF-Client-0.2.0-Source.zip`
- SHA-256: `release/SHA256SUMS.txt`

## 사용 순서

1. 새 데이터로 처음 실행하면 설치된 Java 25 이상을 자동 검색합니다. 기존 설정은 덮어쓰지 않습니다. 기존 사용자는 Settings → Java 자동 검색 → 설정 저장을 누르세요.
2. Instances → 새 인스턴스의 기본값은 **26.3 / Fabric**입니다. 조회된 로더 버전을 선택해 생성하고 게임을 설치하세요.
3. Settings에 자신의 Microsoft 공개 클라이언트 앱 ID를 등록하고, Account에서 공식 Microsoft 페이지로 로그인하세요. 앱의 Xbox/Minecraft 서비스 승인이 필요합니다. 다른 런처의 ID를 빌려 쓰거나 인증을 우회하지 않습니다.
4. My Mods → **DKKF HUD 설치**를 누르면 번들 JAR의 고정 SHA-256을 확인하고 호환 Fabric API를 공식 Modrinth에서 설치합니다.
5. 게임 실행 후 F8은 HUD 편집기, F9는 default/pvp/minimal 프로필 전환입니다.

   26.3에서는 이전 Yarn 이름 대신 공식 비난독화 클래스, HudElementRegistry, GuiGraphicsExtractor, 구조화된 MouseButtonEvent와 새 KeyMapping API를 사용합니다. GLFW 직접 호출도 제거하고 게임의 플랫폼 독립 입력 API로 이식했습니다.

## 유지된 런처 기능

인스턴스 생성·선택·편집·복제·삭제, 공식 게임 다운로드, 다중 로더 메타데이터/설치, 실제 Modrinth 검색·의존성 설치, CurseForge API 연동 코드, JAR 활성/비활성·백업/복원, MRPACK/CurseForge ZIP 입출력, Modrinth 기존 프로젝트 게시 코드, 서명된 업데이트 매니페스트/다운로드 및 로컬 업데이트 서버를 유지합니다.

Microsoft 토큰과 플랫폼 키는 Windows safeStorage로 암호화하고 renderer에 전달하지 않습니다. Electron contextIsolation/sandbox, nodeIntegration 비활성화, IPC 발신 프레임·스키마 검증, HTTPS·출처 제한·파일 해시·ZIP 경로 검증을 유지합니다. 게임 실행 중 파일 변경 작업은 차단합니다.

기존 1.21.1 Fabric 소스와 0.1.0 JAR는 보존했습니다. 현재 활성 Gradle 빌드와 런처의 HUD 설치 대상은 **26.3**입니다. 기존 인스턴스를 자동 변환하거나 모드를 삭제하지 않습니다. 이전 문서는 `docs/archive/0.1.0`에 보존했습니다.

## 검증 범위와 남은 사항

- TESTED: 26.3 공식 메타데이터, Fabric 0.20.1 호환성, 실제 26.3 게임/라이브러리/5,149개 리소스 설치, Fabric API 다운로드와 해시, Java 25 대상 HUD JAR 컴파일·메타데이터·중첩 common JAR 검사
- TESTED: TypeScript·production 빌드, 보안/저장소/모드팩/로컬 업데이트 서버/Java 대상 회귀 테스트 13개
- TESTED: 패키징된 0.2.0 앱의 9개 화면, 26.3/Fabric 기본값, Java 25 이상 검색, 실제 Modrinth 검색, Windows safeStorage 및 HUD 설치. 결과는 `TEST-REPORT.md`에 기록했습니다.
- BLOCKED: 실제 Microsoft 인증·토큰 갱신·게임 창 실행은 자신의 승인된 앱과 소유 계정이 필요합니다. CurseForge 실제 연동은 발급된 키가 필요합니다.
- PARTIAL: HUD의 게임 내 렌더·F8/F9 조작은 실제 인증된 게임에서 아직 검증하지 않았습니다.
- NOT IMPLEMENTED: Forge/NeoForge/Quilt 전용 HUD, 업데이트 설치 후 자동 롤백·무인 설치·일부 설정 옵션

Windows 설치 프로그램은 Authenticode 코드서명 전 개발 빌드입니다. 완성된 상용 제품으로 표시하지 않습니다. 자세한 빌드는 `BUILD.md`, 인증/운영 업데이트 설정은 `DEPLOYMENT.md`, 검증 근거는 `TEST-REPORT.md`를 참고하세요. Minecraft 게임 파일·계정·API 키는 배포 파일에 포함하지 않습니다.
