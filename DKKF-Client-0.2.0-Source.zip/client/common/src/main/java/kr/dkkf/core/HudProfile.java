package kr.dkkf.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** No game or loader types belong in common. All input is provided by adapters. */
public final class HudProfile {
 public static final List<String> MODULES=List.of("FPS","CPS","Ping","Coordinates","Direction","Keystrokes","Armor Status","Potion Status","Clock","Memory Usage");
 public static final class Widget {
  public final String id; public float x,y,scale=1,opacity=.8f; public int color=0x73eee0; public boolean enabled=true;
  public Widget(String id,float x,float y){this.id=id;this.x=x;this.y=y;}
 }
 public final List<Widget> widgets=new ArrayList<>();
 private final Path directory; public String name="default";
 public HudProfile(Path directory){this.directory=directory;reset();}
 private void reset(){widgets.clear();int n=0;for(String id:MODULES)widgets.add(new Widget(id,8,8+18*n++));}
 public void load(String profile) throws IOException {
  if(!Set.of("default","pvp","minimal").contains(profile))throw new IllegalArgumentException("Unknown profile");name=profile;reset();Path file=directory.resolve(profile+".properties");if(!Files.exists(file))return;
  Properties p=new Properties();try(InputStream in=Files.newInputStream(file)){p.load(in);}for(Widget w:widgets){String k=w.id+".";try{w.x=clamp(Float.parseFloat(p.getProperty(k+"x","8")),0,10000);w.y=clamp(Float.parseFloat(p.getProperty(k+"y",String.valueOf(w.y))),0,10000);w.scale=clamp(Float.parseFloat(p.getProperty(k+"scale","1")),.5f,3);w.opacity=clamp(Float.parseFloat(p.getProperty(k+"opacity",".8")),.1f,1);w.color=Integer.parseInt(p.getProperty(k+"color","7597792"))&0xffffff;w.enabled=Boolean.parseBoolean(p.getProperty(k+"enabled","true"));}catch(NumberFormatException ignored){/* Invalid widget retains safe defaults. */}}
 }
 public void save() throws IOException {Files.createDirectories(directory);Properties p=new Properties();for(Widget w:widgets){String k=w.id+".";p.setProperty(k+"x",String.valueOf(w.x));p.setProperty(k+"y",String.valueOf(w.y));p.setProperty(k+"scale",String.valueOf(w.scale));p.setProperty(k+"opacity",String.valueOf(w.opacity));p.setProperty(k+"color",String.valueOf(w.color));p.setProperty(k+"enabled",String.valueOf(w.enabled));}Path temp=directory.resolve(name+".tmp");try(OutputStream out=Files.newOutputStream(temp)){p.store(out,"DKKF HUD profile");}Files.move(temp,directory.resolve(name+".properties"),StandardCopyOption.REPLACE_EXISTING);}
 public static float clamp(float v,float min,float max){return Float.isFinite(v)?Math.max(min,Math.min(max,v)):min;}
}
