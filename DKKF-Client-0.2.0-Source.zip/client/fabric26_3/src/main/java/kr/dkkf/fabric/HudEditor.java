package kr.dkkf.fabric;

import kr.dkkf.core.HudProfile;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** 26.3 screen extraction and structured mouse input adapter. */
public final class HudEditor extends Screen {
    private HudProfile.Widget selected;
    private double offsetX, offsetY;
    private boolean dragging;

    public HudEditor() { super(Component.literal("DKKF HUD Editor")); }

    @Override protected void init() {
        DkkfClient.editing = true;
        int y = height - 28;
        addRenderableWidget(Button.builder(Component.literal("Toggle"), b -> { if (selected != null) selected.enabled = !selected.enabled; }).bounds(8, y, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Color"), b -> { if (selected != null) selected.color = selected.color == 0x73eee0 ? 0xb69bff : selected.color == 0xb69bff ? 0xffffff : 0x73eee0; }).bounds(83, y, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Opacity"), b -> { if (selected != null) selected.opacity = selected.opacity <= .3f ? 1 : selected.opacity - .2f; }).bounds(158, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Save & close"), b -> onClose()).bounds(width - 120, y, 112, 20).build());
    }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mx, int my, float delta) {
        graphics.fill(0, 0, width, height, 0xa008101c);
        graphics.centeredText(font, "DKKF HUD · drag to move · scroll to resize · profile: " + DkkfClient.profile.name, width / 2, 12, 0xff78ead8);
        DkkfClient.render(graphics, true);
        if (selected != null) graphics.centeredText(font, selected.id + " | scale " + String.format(java.util.Locale.ROOT, "%.1f", selected.scale), width / 2, height - 45, 0xffbdcde0);
        super.extractRenderState(graphics, mx, my, delta);
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        dragging = false;
        if (super.mouseClicked(event, doubleClick)) return true;
        var widgets = DkkfClient.profile.widgets;
        for (int n = widgets.size() - 1; n >= 0; n--) {
            var widget = widgets.get(n);
            int textWidth = font.width(DkkfClient.text(widget)) + 10;
            if (event.x() >= widget.x - 2 && event.x() <= widget.x + textWidth * widget.scale && event.y() >= widget.y - 2 && event.y() <= widget.y + 14 * widget.scale) {
                selected = widget;
                offsetX = event.x() - widget.x;
                offsetY = event.y() - widget.y;
                dragging = event.button() == InputConstants.MOUSE_BUTTON_LEFT;
                return true;
            }
        }
        return false;
    }

    @Override public boolean mouseReleased(MouseButtonEvent event) { dragging = false; return super.mouseReleased(event); }
    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (selected != null && dragging && event.button() == InputConstants.MOUSE_BUTTON_LEFT) {
            selected.x = HudProfile.clamp((float) (event.x() - offsetX), 2, Math.max(2, width - 20));
            selected.y = HudProfile.clamp((float) (event.y() - offsetY), 28, Math.max(28, height - 55));
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }
    @Override public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        if (selected != null) { selected.scale = HudProfile.clamp(selected.scale + (float) vertical * .1f, .5f, 3); return true; }
        return super.mouseScrolled(x, y, horizontal, vertical);
    }
    @Override public void removed() {
        DkkfClient.editing = false;
        try { DkkfClient.profile.save(); } catch (Exception e) { DkkfClient.LOG.warn("Cannot save HUD settings", e); }
        super.removed();
    }
    @Override public boolean isPauseScreen() { return false; }
}
