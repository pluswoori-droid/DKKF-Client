# Test report — 0.2.0 / Minecraft 26.3 Fabric

검증일: 2026-11-16 (Asia/Seoul). Windows 11 x64, JDK 26.0.2.1, Gradle 9.5.0, Loom 1.17.21. 코어 대상 바이트코드는 Java 25입니다.

## 실제 공식 서버 연동

[검증 결과](docs/verification/live-26.3.json).

| 검사                               | 결과    | 범위                                                                          |
| ---------------------------------- | ------- | ----------------------------------------------------------------------------- |
| 26.3 공식 manifest / Fabric 로더   | TESTED  | 공식 Mojang 버전과 안정 Fabric 0.20.1 확인                                    |
| 실제 Fabric API 다운로드           | TESTED  | 26.3 호환 API 다운로드·공식 SHA-512 및 로컬 SHA-256 검사                      |
| 실제 Minecraft 26.3 Fabric 설치    | TESTED  | 공식 client JAR·라이브러리·네이티브·5,149개 리소스 객체 다운로드·해시 검사    |
| 실행 프로필                        | TESTED  | Fabric KnotClient, Minecraft 26.3, javaVersion.majorVersion=25                |
| 실제 Microsoft 로그인·게임 창 실행 | BLOCKED | 승인된 본인 앱과 소유 계정 없음. 설치 성공을 게임 실행 성공으로 간주하지 않음 |

## 코어 / 빌드

| 검사                                     | 결과    | 범위                                              |
| ---------------------------------------- | ------- | ------------------------------------------------- |
| 26.3 HUD Java 컴파일                     | TESTED  | Gradle build 성공; 공식 비난독화 API로 이식       |
| JAR metadata / SHA-256                   | TESTED  | minecraft=26.3, java>=25, version=0.2.0           |
| 바이트코드·common 포함                   | TESTED  | 세 어댑터 클래스 major=69, nested common JAR 존재 |
| TypeScript strict / Vite / Electron 번들 | TESTED  | production 빌드 통과                              |
| 자동 회귀 테스트                         | TESTED  | 13개 통과, 실패 0                                 |
| 실제 HUD 렌더·F8/F9 조작                 | PARTIAL | 컴파일·설치만 검증. 실제 인증 게임 내 동작 미검증 |

[코어 아티팩트 검사](docs/verification/core-26.3.json), [자동 테스트 출력](docs/verification/automated-tests-26.3.txt).

13개 테스트는 기존 보안/SQLite/로컬 모드/백업복원/MRPACK/서명 프로토콜/로컬 REST·WebSocket 12개와 26.3 Fabric 대상·Java major parser 회귀 검사 1개입니다. 합성 JAR/업데이트와 loopback 서비스는 실제 외부 계정/API 연동과 구분합니다.

## 패키징된 0.2.0 앱

**TESTED**: 최종 패키징 앱에서 9개 화면 이동, 새 인스턴스의 26.3/Fabric 기본값, 실제 Modrinth 검색, Windows safeStorage, Java 25 이상 검색(실제 Java 26 발견), 번들 HUD 해시 및 Fabric API 설치를 통과했습니다. renderer 오류는 0개입니다. [최종 UI 검증 근거](docs/verification/packaged-ui-26.3.json).

NSIS 설치 프로그램은 생성 및 unpacked 실행 파일을 검증합니다. 사용자 시스템에 실제 설치·제거·업그레이드는 하지 않으며 Authenticode 서명은 없습니다.

## 변경 및 제한

26.3의 HudElementRegistry/GuiGraphicsExtractor, 새 KeyMapping, 구조화된 MouseButtonEvent API로 이식했습니다. GLFW 직접 참조를 제거하고 Minecraft 입력 상태를 사용합니다. 기본 인스턴스는 26.3 Fabric이고 초기 설정의 Java는 25 이상을 자동 검색합니다. 기존 사용자의 저장된 Java 경로·인스턴스·모드는 덮어쓰지 않습니다.

기존 인증/CurseForge의 외부 권한 요구, Forge/NeoForge/Quilt 전용 HUD 미구현, 무인 업데이트·설치 후 자동 롤백 미구현 상태는 유지합니다. 이전 1.21.1 검증 결과는 `docs/archive/0.1.0/TEST-REPORT.md`에 보존하며 26.3의 검증으로 재사용하지 않습니다.
