export type Loader = 'vanilla' | 'fabric' | 'quilt' | 'forge' | 'neoforge';
export interface Instance {
  id: string;
  name: string;
  version: string;
  loader: Loader;
  loaderVersion: string;
  ram: number;
  created: string;
  lastPlayed?: string;
  profileId?: string;
  installed?: boolean;
}
export interface Settings {
  javaPath: string;
  ram: number;
  width: number;
  height: number;
  fullscreen: boolean;
  autoUpdate: boolean;
  channel: 'stable' | 'beta';
  microsoftClientId: string;
  updateUrl: string;
  updateKey: string;
  language: 'ko' | 'en';
}
export interface Account {
  id: string;
  name: string;
  expires: number;
}
export interface Mod {
  file: string;
  name: string;
  id: string;
  version: string;
  authors: string[];
  enabled: boolean;
  sha256: string;
  depends: string[];
  source?: { provider: 'modrinth' | 'curseforge'; project: string; version: string };
  warnings: string[];
}
export interface Progress {
  task: string;
  message: string;
  current: number;
  total: number;
}
export interface Snapshot {
  instances: Instance[];
  settings: Settings;
  accounts: Account[];
  selected?: string;
  running?: string;
  version: string;
  busy: boolean;
}
export interface Bridge {
  call<T = any>(method: string, args?: unknown): Promise<T>;
  onEvent(fn: (event: { type: string; data: any }) => void): () => void;
}
declare global {
  interface Window {
    dkkf: Bridge;
  }
}
