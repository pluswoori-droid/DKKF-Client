import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign, randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { Store } from '../launcher/main/store';
import { Updater } from '../launcher/main/updater';
test('signed update protocol accepts newer versions, rejects tampering/channel mismatch/downgrades; failed checks preserve installation', async () => {
  const root = path.resolve('.data/tests/' + randomUUID());
  const store = await new Store(root).init(path.resolve('node_modules/sql.js/dist/sql-wasm.wasm'));
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  store.set('settings', {
    updateUrl: 'https://updates.example.com',
    updateKey: publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    channel: 'stable',
  });
  const payload = {
    version: '1.2.3',
    channel: 'stable',
    target: 'launcher',
    url: 'https://updates.example.com/setup.exe',
    sha256: 'a'.repeat(64),
    size: 1000,
    published: new Date().toISOString(),
    notes: 'Fixture, not a real release',
  };
  const envelope = (p: any) => ({
    payload: p,
    signature: sign(null, Buffer.from(JSON.stringify(p)), privateKey).toString('base64'),
  });
  let response = envelope(payload);
  const updater = new Updater(
    store,
    () => {},
    { version: '0.1.0', packaged: false, quit: () => {} },
    async () => response,
  );
  try {
    assert.equal((await updater.check()).status, 'available');
    response = { ...envelope(payload), payload: { ...payload, sha256: 'b'.repeat(64) } };
    await assert.rejects(() => updater.check(), /서명/);
    response = envelope({ ...payload, channel: 'beta' });
    await assert.rejects(() => updater.check(), /채널/);
    response = envelope({ ...payload, version: '0.0.1' });
    assert.equal((await updater.check()).status, 'current');
    response = envelope({ ...payload, url: 'http://insecure.example.com/setup.exe' });
    await assert.rejects(() => updater.check(), /HTTPS/);
    await assert.rejects(() => updater.install(), /패키징/);
    assert.equal(store.instances.length, 0);
  } finally {
    store.close();
    await fs.rm(root, { recursive: true, force: true });
  }
});
