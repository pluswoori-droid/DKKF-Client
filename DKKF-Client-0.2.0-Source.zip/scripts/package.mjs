import { spawnSync } from 'node:child_process';
for (const [script, args] of [
  ['node_modules/typescript/bin/tsc', ['--noEmit']],
  ['node_modules/vite/bin/vite.js', ['build']],
  ['scripts/build.mjs', []],
  ['node_modules/electron-builder/cli.js', ['--win', 'nsis', '--x64']],
]) {
  const r = spawnSync(process.execPath, [script, ...args], { stdio: 'inherit' });
  if (r.status !== 0) process.exit(r.status || 1);
}
