import fs from 'node:fs/promises';
import path from 'node:path';
import AdmZip from 'adm-zip';
import { safeEntries } from './archive';
import { json, request } from './network';
export async function uploadVersion(
  token: string,
  input: {
    project: string;
    name: string;
    version: string;
    changelog: string;
    gameVersions: string[];
    loaders: string[];
  },
  file: string,
) {
  if (!token) throw Error('Settings에 프로젝트 작성 권한이 있는 Modrinth 토큰을 저장하세요.');
  const headers = { Authorization: token };
  const me = await json('https://api.modrinth.com/v2/user', { headers });
  const project = await json(
    'https://api.modrinth.com/v2/project/' + encodeURIComponent(input.project),
    { headers },
  );
  const team = await json('https://api.modrinth.com/v2/team/' + project.team + '/members', {
    headers,
  });
  const member = team.find((m: any) => m.user.id === me.id && m.accepted);
  if (!member || !(member.role === 'Owner' || (member.permissions & 1) === 1))
    throw Error('이 프로젝트의 버전 게시 권한이 없습니다.');
  const stat = await fs.stat(file);
  if (stat.size > 100 * 1024 ** 2 || !['.jar', '.mrpack'].includes(path.extname(file)))
    throw Error('100 MiB 이하 JAR 또는 MRPACK 파일이 필요합니다.');
  safeEntries(new AdmZip(file));
  const form = new FormData();
  form.append(
    'data',
    JSON.stringify({
      project_id: project.id,
      name: input.name,
      version_number: input.version,
      changelog: input.changelog,
      dependencies: [],
      game_versions: input.gameVersions,
      loaders: input.loaders,
      version_type: 'release',
      featured: false,
      file_parts: ['file'],
      primary_file: 'file',
    }),
  );
  form.append('file', new Blob([await fs.readFile(file)]), path.basename(file));
  // Fetch exposes completion, not upload byte progress; UI must use an indeterminate state.
  return (
    await request('https://api.modrinth.com/v2/version', { method: 'POST', headers, body: form })
  ).json();
}
