import { app, BrowserWindow, ipcMain, dialog, shell, safeStorage } from 'electron';
import path from 'node:path';
import fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { z } from 'zod';
import { WebSocket } from 'ws';
import { Store } from './store';
import { Auth } from './auth';
import { Minecraft } from './minecraft';
import { Mods } from './mods';
import { Packs } from './packs';
import { Updater } from './updater';
import { uploadVersion } from './upload';
import { id, instanceInput, settingsInput } from '../../shared/schemas';
import { redact, httpsUrl, verifySigned, digest } from './security';
import type { Instance } from '../../shared/types';
import coreBuild from '../../shared/core-build.json';
import target from '../../shared/target.json';
import { discoverJava } from './java';
let win: BrowserWindow,
  store: Store,
  auth: Auth,
  mc: Minecraft,
  mods: Mods,
  packs: Packs,
  updater: Updater;
let controller: AbortController | undefined,
  running: string | undefined,
  closing = false,
  socket: WebSocket | undefined;
let eventStamp = 0;
const emit = (type: string, data: any) => {
  if (type === 'progress' && Date.now() - eventStamp < 80 && data.current !== data.total) return;
  if (type === 'progress') eventStamp = Date.now();
  if (win && !win.isDestroyed()) win.webContents.send('dkkf:event', { type, data });
};
const state = () => ({
  instances: store.instances,
  settings: store.settings,
  accounts: store.accounts,
  selected: store.get('selected', ''),
  activeAccount: store.get('activeAccount', ''),
  running,
  version: app.getVersion(),
  busy: !!controller,
  packs: store.get('packs', []),
});
const changed = () => emit('state', state());
const idle = () => {
  if (running) throw Error('게임 실행 중에는 파일을 변경할 수 없습니다.');
  if (controller) throw Error('진행 중인 작업이 있습니다.');
};
async function task<T>(fn: (signal: AbortSignal) => Promise<T>) {
  idle();
  controller = new AbortController();
  changed();
  try {
    return await fn(controller.signal);
  } finally {
    controller.abort();
    controller = undefined;
    changed();
  }
}
const secretFile = (key: string) => path.join(store.root, 'secrets', key + '.vault');
async function getSecret(key: string) {
  try {
    return safeStorage.decryptString(await fs.readFile(secretFile(key)));
  } catch (e: any) {
    if (e.code === 'ENOENT') return '';
    throw e;
  }
}
async function setSecret(key: string, value: string) {
  if (!safeStorage.isEncryptionAvailable())
    throw Error('Windows 암호화 저장소를 사용할 수 없습니다.');
  await fs.mkdir(path.dirname(secretFile(key)), { recursive: true });
  if (!value) {
    await fs.rm(secretFile(key), { force: true });
    return;
  }
  const tmp = secretFile(key) + '.tmp';
  await fs.writeFile(tmp, safeStorage.encryptString(value));
  await fs.rename(tmp, secretFile(key));
}
function connectAnnouncements() {
  socket?.close();
  socket = undefined;
  const s = store.settings;
  if (!s.updateUrl || !s.updateKey) return;
  const url = new URL(s.updateUrl.replace(/\/$/, '') + '/announcements');
  url.protocol = 'wss:';
  socket = new WebSocket(url, { maxPayload: 12000 });
  socket.on('message', (raw) => {
    try {
      const d = JSON.parse(raw.toString());
      verifySigned(d.payload, d.signature, s.updateKey);
      const p = z
        .object({ message: z.string().max(2000), published: z.iso.datetime() })
        .parse(d.payload);
      if (Math.abs(Date.now() - Date.parse(p.published)) > 5 * 60000) throw Error('만료된 공지');
      emit('notice', p.message);
    } catch {
      emit('notice', '검증되지 않은 서버 공지를 차단했습니다.');
    }
  });
  socket.on('error', () => {});
}
async function chooseFile(extensions: string[], multiple = false) {
  const r = await dialog.showOpenDialog(win, {
    properties: multiple ? ['openFile', 'multiSelections'] : ['openFile'],
    filters: [{ name: 'Supported files', extensions }],
  });
  return r.canceled ? [] : r.filePaths;
}
const methods: Record<string, (a: any) => unknown> = {
  state: () => state(),
  versions: () => mc.manifest(),
  loaders: (a) => {
    const q = z.object({ loader: instanceInput.shape.loader, version: id }).parse(a);
    return mc.loaders(q.loader, q.version);
  },
  'instances.create': (a) =>
    task(async () => {
      const v = instanceInput.parse(a);
      if (v.loader !== 'vanilla' && !v.loaderVersion) throw Error('로더 버전을 선택하세요.');
      if (v.loaderVersion) id.parse(v.loaderVersion);
      const all = await mc.manifest();
      if (!all.versions.some((x: any) => x.id === v.version))
        throw Error('공식 게임 버전이 아닙니다.');
      const item: Instance = { ...v, id: randomUUID(), created: new Date().toISOString() };
      await fs.mkdir(path.join(store.root, 'instances', item.id), { recursive: true });
      store.saveInstance(item);
      store.set('selected', item.id);
      return item;
    }),
  'instances.select': (a) => {
    const i = store.instance(id.parse(a));
    store.set('selected', i.id);
    changed();
  },
  'instances.edit': (a) =>
    task(async () => {
      const q = z
        .object({
          id,
          name: z.string().trim().min(1).max(70),
          ram: z.number().int().min(1024).max(65536),
        })
        .parse(a);
      store.saveInstance({ ...store.instance(q.id), name: q.name, ram: q.ram });
    }),
  'instances.delete': (a) =>
    task(async () => {
      const key = id.parse(a);
      const i = store.instance(key);
      const r = await dialog.showMessageBox(win, {
        type: 'warning',
        message: `${i.name} 인스턴스와 저장된 월드를 삭제할까요?`,
        buttons: ['취소', '삭제'],
        defaultId: 0,
        cancelId: 0,
      });
      if (r.response !== 1) return;
      await fs.rm(store.dir(key), { recursive: true, force: true });
      store.set(
        'instances',
        store.instances.filter((i) => i.id !== key),
      );
      store.set(
        'packs',
        store.get<string[]>('packs', []).filter((x) => x !== key),
      );
      if (store.get('selected', '') === key) store.set('selected', store.instances[0]?.id || '');
    }),
  'instances.clone': (a) =>
    task(async () => {
      const i = store.instance(id.parse(a));
      const item = {
        ...i,
        id: randomUUID(),
        name: i.name + ' Copy',
        created: new Date().toISOString(),
        lastPlayed: undefined,
      };
      const dest = path.join(store.root, 'instances', item.id);
      try {
        await fs.cp(store.dir(i.id), dest, {
          recursive: true,
          filter: (src) => !['logs', 'backups', 'updates'].includes(path.basename(src)),
        });
        store.saveInstance(item);
        store.set('modSources:' + item.id, store.get('modSources:' + i.id, {}));
        if (store.get<string[]>('packs', []).includes(i.id))
          store.set('packs', [...store.get<string[]>('packs', []), item.id]);
        return item;
      } catch (e) {
        await fs.rm(dest, { recursive: true, force: true });
        throw e;
      }
    }),
  'instances.folder': (a) => shell.openPath(store.dir(id.parse(a))),
  'game.install': (a) => task((signal) => mc.install(store.instance(id.parse(a)), signal)),
  'game.launch': async (a) => {
    idle();
    const i = store.instance(id.parse(a));
    if (!i.installed) throw Error('먼저 게임을 설치하세요.');
    running = i.id;
    changed();
    try {
      const creds = await auth.credentials();
      const logDir = path.join(store.dir(i.id), 'logs');
      await fs.mkdir(logDir, { recursive: true });
      const logfile = path.join(logDir, 'launcher-' + Date.now() + '.log');
      const started = new Date().toISOString();
      let logQueue = Promise.resolve();
      await mc.launch(
        i,
        creds,
        (s) => {
          const clean = redact(s.replaceAll(creds.token, '[REDACTED]'));
          logQueue = logQueue.then(() => fs.appendFile(logfile, clean)).catch(() => {});
          emit('log', clean.slice(-8000));
        },
        (code) => {
          running = undefined;
          store.db.run('INSERT INTO history(instance,started,exit_code) VALUES (?,?,?)', [
            i.id,
            started,
            code,
          ]);
          store.flush();
          emit('notice', `게임 종료 (코드 ${code})`);
          changed();
        },
      );
      store.saveInstance({ ...i, lastPlayed: started });
      return { started: true };
    } catch (e) {
      running = undefined;
      changed();
      throw e;
    }
  },
  history: () =>
    store.db
      .exec('SELECT instance,started,exit_code FROM history ORDER BY id DESC LIMIT 20')
      .map((r) => r.values)
      .flat(),
  'auth.begin': () => {
    if (running) throw Error('게임 종료 후 계정을 변경하세요.');
    return auth.begin();
  },
  'auth.poll': async () => {
    const r = await auth.poll();
    changed();
    return r;
  },
  'auth.cancel': () => auth.cancel(),
  'auth.select': (a) => {
    if (running) throw Error('게임 종료 후 변경하세요.');
    const key = id.parse(a);
    if (!store.accounts.some((x) => x.id === key)) throw Error('계정이 없습니다.');
    store.set('activeAccount', key);
    changed();
  },
  'auth.logout': async (a) => {
    if (running) throw Error('게임 종료 후 로그아웃하세요.');
    await auth.logout(id.parse(a));
    changed();
  },
  'mods.list': (a) => mods.list(id.parse(a)),
  'mods.import': (a) =>
    task(async () => {
      const key = id.parse(a);
      const files = await chooseFile(['jar'], true);
      if (!files.length) return;
      const result = await dialog.showMessageBox(win, {
        type: 'warning',
        message:
          'JAR 모드는 게임과 동일한 권한으로 실행됩니다. 신뢰할 수 있는 제작자의 파일만 가져오세요.',
        buttons: ['취소', '가져오기'],
        defaultId: 0,
        cancelId: 0,
      });
      if (result.response === 1) return mods.import(key, files);
    }),
  'mods.toggle': (a) =>
    task(async () => {
      const q = z.object({ id, file: z.string().max(240) }).parse(a);
      await mods.toggle(q.id, q.file);
    }),
  'mods.remove': (a) =>
    task(async () => {
      const q = z.object({ id, file: z.string().max(240) }).parse(a);
      await mods.backup(q.id);
      await mods.remove(q.id, q.file);
    }),
  'mods.backup': (a) => task(() => mods.backup(id.parse(a))),
  'mods.backups': async (a) => {
    try {
      return await fs.readdir(path.join(store.dir(id.parse(a)), 'backups'));
    } catch {
      return [];
    }
  },
  'mods.restore': (a) =>
    task(() => {
      const q = z.object({ id, name: z.string() }).parse(a);
      return mods.restore(q.id, q.name);
    }),
  'mods.search': (a) => {
    const q = z
      .object({
        provider: z.enum(['modrinth', 'curseforge']),
        query: z.string().max(200),
        instance: id.optional(),
        sort: z.enum(['relevance', 'downloads', 'newest', 'updated']).default('relevance'),
        category: z.string().max(60).default(''),
      })
      .parse(a);
    return mods.search(
      q.provider,
      q.query,
      q.instance ? store.instance(q.instance) : undefined,
      q.sort,
      q.category,
    );
  },
  'mods.detail': (a) => {
    const q = z
      .object({ provider: z.enum(['modrinth', 'curseforge']), project: id, instance: id })
      .parse(a);
    return mods.detail(q.provider, q.project, store.instance(q.instance));
  },
  'mods.install': (a) =>
    task((signal) => {
      const q = z
        .object({ id, provider: z.enum(['modrinth', 'curseforge']), project: id, version: id })
        .parse(a);
      return mods.install(q.id, q.provider, q.project, q.version, signal);
    }),
  'mods.updates': (a) => mods.updates(id.parse(a)),
  'core.install': (a) =>
    task(async (signal) => {
      const i = store.instance(id.parse(a));
      if (i.version !== coreBuild.minecraft || i.loader !== coreBuild.loader)
        throw Error(`현재 HUD 코어는 Minecraft ${coreBuild.minecraft} Fabric 전용입니다.`);
      const file = path.join(
        app.isPackaged ? process.resourcesPath : path.join(app.getAppPath(), 'assets'),
        'client-core',
        coreBuild.file,
      );
      if ((await digest(file)) !== coreBuild.sha256) throw Error('번들 HUD 코어 무결성 검사 실패');
      const existing = (await mods.list(i.id)).find((m) => m.id === 'dkkf_core');
      if (existing?.sha256 === coreBuild.sha256) return { installed: true };
      const api = await mods.detail('modrinth', 'fabric-api', i);
      if (!api.versions[0]) throw Error('호환 Fabric API가 없습니다.');
      await mods.install(i.id, 'modrinth', 'fabric-api', api.versions[0].id, signal);
      await mods.backup(i.id);
      if (existing) await mods.remove(i.id, existing.file);
      await mods.import(i.id, [file]);
      return { installed: true };
    }),
  'packs.mark': (a) => {
    idle();
    const i = store.instance(id.parse(a));
    store.set('packs', Array.from(new Set([...store.get<string[]>('packs', []), i.id])));
    changed();
  },
  'packs.import': () =>
    task(async (signal) => {
      const files = await chooseFile(['mrpack', 'zip']);
      return files[0] ? packs.import(files[0], signal) : undefined;
    }),
  'packs.export': (a) =>
    task(async () => {
      const q = z.object({ id, format: z.enum(['mrpack', 'curseforge']) }).parse(a);
      const ext = q.format === 'mrpack' ? 'mrpack' : 'zip';
      const r = await dialog.showSaveDialog(win, {
        defaultPath: store.instance(q.id).name + '.' + ext,
        filters: [{ name: 'Modpack', extensions: [ext] }],
      });
      return !r.canceled && r.filePath ? packs.export(q.id, r.filePath, q.format) : undefined;
    }),
  'settings.save': (a) => {
    idle();
    store.set('settings', settingsInput.parse(a));
    connectAnnouncements();
    changed();
  },
  'settings.secret': async (a) => {
    const q = z
      .object({ key: z.enum(['curseforge', 'modrinth']), value: z.string().max(2000) })
      .parse(a);
    await setSecret(q.key, q.value);
    return { saved: true };
  },
  'settings.secrets': async () => ({
    curseforge: !!(await getSecret('curseforge')),
    modrinth: !!(await getSecret('modrinth')),
  }),
  'settings.java': async () => {
    const files = await chooseFile(['exe']);
    return files[0];
  },
  'settings.javaAuto': async () => {
    const found = await discoverJava(target.java);
    if (!found)
      throw Error(
        `Java ${target.java} 이상을 찾지 못했습니다. 설치 후 java.exe를 직접 선택하세요.`,
      );
    return found;
  },
  'settings.data': () => shell.openPath(store.root),
  'update.check': () => updater.check(),
  'update.download': () => task((signal) => updater.fetch(signal)),
  'update.install': () => {
    idle();
    return updater.install();
  },
  'task.cancel': () => controller?.abort(),
  'upload.version': (a) =>
    task(async () => {
      const q = z
        .object({
          project: id,
          name: z.string().min(1).max(100),
          version: z.string().min(1).max(60),
          changelog: z.string().max(50000),
          gameVersions: z.array(id).min(1),
          loaders: z.array(instanceInput.shape.loader).min(1),
        })
        .parse(a);
      const files = await chooseFile(['jar', 'mrpack']);
      return files[0] ? uploadVersion(await getSecret('modrinth'), q, files[0]) : undefined;
    }),
  external: (a) => {
    const u = httpsUrl(z.string().parse(a), [
      'modrinth.com',
      'curseforge.com',
      'microsoft.com',
      'microsoftonline.com',
    ]);
    return shell.openExternal(u.href);
  },
};
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => {
    if (win) {
      win.show();
      win.focus();
    }
  });
  app
    .whenReady()
    .then(async () => {
      const wasm = app.isPackaged
        ? path.join(process.resourcesPath, 'sql-wasm.wasm')
        : path.join(app.getAppPath(), 'node_modules/sql.js/dist/sql-wasm.wasm');
      store = await new Store(
        process.env.DKKF_DATA_DIR || path.join(app.getPath('userData'), 'data'),
      ).init(wasm);
      if (!store.get<{ javaPath?: string }>('settings', {}).javaPath) {
        const found = await discoverJava(target.java);
        if (found) store.set('settings', { ...store.settings, javaPath: found.path });
      }
      auth = new Auth(store);
      mc = new Minecraft(store, (p) => emit('progress', p));
      mods = new Mods(store, getSecret);
      packs = new Packs(store, mods);
      updater = new Updater(store, emit, {
        version: app.getVersion(),
        packaged: app.isPackaged,
        quit: () => app.quit(),
      });
      const entry = path.join(__dirname, '../renderer/index.html');
      const dev = process.env.DKKF_DEV === '1' && !app.isPackaged;
      const trusted = dev ? 'http://127.0.0.1:5173/' : pathToFileURL(entry).href;
      win = new BrowserWindow({
        width: 1440,
        height: 940,
        minWidth: 1080,
        minHeight: 720,
        backgroundColor: '#080b13',
        title: 'DKKF Client · Neon Edition',
        icon: app.isPackaged
          ? path.join(process.resourcesPath, 'icon.png')
          : path.join(app.getAppPath(), 'assets/icon.png'),
        autoHideMenuBar: true,
        webPreferences: {
          preload: path.join(__dirname, 'preload.cjs'),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true,
          webSecurity: true,
        },
      });
      win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
      win.webContents.on('will-navigate', (e, url) => {
        if (url !== trusted) e.preventDefault();
      });
      win.webContents.session.setPermissionRequestHandler((_w, _p, cb) => cb(false));
      ipcMain.handle('dkkf:call', async (e, method: unknown, args: unknown) => {
        if (
          e.sender !== win.webContents ||
          e.senderFrame !== win.webContents.mainFrame ||
          e.senderFrame.url.split('#')[0] !== trusted
        )
          throw Error('신뢰되지 않은 IPC 발신자');
        if (typeof method !== 'string' || !Object.hasOwn(methods, method))
          throw Error('지원하지 않는 요청');
        try {
          return { ok: true, data: await methods[method](args) };
        } catch (error) {
          return {
            ok: false,
            error: redact(error instanceof Error ? error.message : String(error)),
          };
        }
      });
      if (dev) await win.loadURL(trusted);
      else await win.loadFile(entry);
      win.on('close', (e) => {
        if ((running || controller) && !closing) {
          e.preventDefault();
          void dialog.showMessageBox(win, {
            type: 'info',
            message: '진행 중인 작업을 취소하고 게임을 종료한 다음 런처를 닫으세요.',
            buttons: ['확인'],
          });
        }
      });
      connectAnnouncements();
      const auto = async () => {
        if (!store.settings.autoUpdate || controller || running) return;
        try {
          const r = await updater.check();
          emit('update', r);
          if (r.status === 'available') await task((signal) => updater.fetch(signal));
        } catch (e) {
          emit('notice', '업데이트 확인 실패: ' + (e as Error).message);
        }
      };
      void auto();
      setInterval(() => void auto(), 300000).unref();
    })
    .catch((e) => {
      dialog.showErrorBox('DKKF 시작 실패', redact(String(e)));
      app.quit();
    });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => {
    closing = true;
    controller?.abort();
    socket?.close();
  });
}
