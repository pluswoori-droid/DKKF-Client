import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { z } from 'zod';
import { json, download } from './network';
import { verifySigned, digest, httpsUrl } from './security';
import type { Store } from './store';
const payloadSchema = z
  .object({
    version: z.string().regex(/^\d+\.\d+\.\d+$/),
    channel: z.enum(['stable', 'beta']),
    target: z.literal('launcher'),
    url: z.url(),
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
    size: z
      .number()
      .int()
      .positive()
      .max(1024 ** 3),
    published: z.iso.datetime(),
    notes: z.string().max(10000),
  })
  .strict();
export class Updater {
  available?: z.infer<typeof payloadSchema>;
  ready?: string;
  constructor(
    private store: Store,
    private emit: (type: string, data: any) => void,
    private runtime: { version: string; packaged: boolean; quit: () => void },
    private readJson: typeof json = json,
  ) {}
  async check() {
    const s = this.store.settings;
    if (!s.updateUrl || !s.updateKey)
      return {
        status: 'unconfigured',
        message: '배포 서버 HTTPS 주소와 신뢰할 Ed25519 공개키를 설정하세요.',
      };
    const envelope = await this.readJson(
      s.updateUrl.replace(/\/$/, '') + '/' + s.channel + '.json',
    );
    verifySigned(envelope.payload, envelope.signature, s.updateKey);
    const p = payloadSchema.parse(envelope.payload);
    httpsUrl(p.url);
    if (p.channel !== s.channel) throw Error('업데이트 채널 불일치');
    const newer = (a: string, b: string) => {
      const aa = a.split('.').map(Number),
        bb = b.split('.').map(Number);
      for (let n = 0; n < 3; n++) {
        if (aa[n] !== bb[n]) return aa[n] > bb[n];
      }
      return false;
    };
    if (!newer(p.version, this.runtime.version))
      return { status: 'current', version: this.runtime.version };
    this.available = p;
    return { status: 'available', ...p };
  }
  async fetch(signal: AbortSignal) {
    if (!this.available) throw Error('검증된 업데이트가 없습니다.');
    const p = this.available;
    const stage = path.join(this.store.root, 'updates', p.version);
    await fs.mkdir(stage, { recursive: true });
    const target = path.join(stage, 'DKKF-Setup.exe');
    await download(
      p.url,
      target,
      { algorithm: 'sha256', value: p.sha256 },
      signal,
      (n, t) =>
        this.emit('progress', {
          task: 'update',
          message: '런처 업데이트 다운로드',
          current: n,
          total: t,
        }),
      [new URL(p.url).hostname],
    );
    if ((await fs.stat(target)).size !== p.size) {
      await fs.rm(target);
      throw Error('업데이트 크기 불일치');
    }
    await fs.writeFile(path.join(stage, 'verified.json'), JSON.stringify(p));
    this.ready = target;
    return { status: 'ready', version: p.version };
  }
  async install() {
    if (!this.ready || !this.available || !this.runtime.packaged)
      throw Error('패키징된 런처에서만 검증한 설치 프로그램을 실행할 수 있습니다.');
    if ((await digest(this.ready)) !== this.available.sha256)
      throw Error('설치 직전 해시 검증 실패');
    const child = spawn(this.ready, [], { detached: true, stdio: 'ignore', windowsHide: true });
    await new Promise<void>((resolve, reject) => {
      child.once('spawn', resolve);
      child.once('error', reject);
    });
    child.unref();
    this.runtime.quit();
  }
}
