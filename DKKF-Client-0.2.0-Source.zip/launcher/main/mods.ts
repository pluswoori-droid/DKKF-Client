import fs from 'node:fs/promises';
import path from 'node:path';
import AdmZip from 'adm-zip';
import { createHash, randomUUID } from 'node:crypto';
import { contained, digest } from './security';
import { json, download } from './network';
import { extract, safeEntries } from './archive';
import type { Store } from './store';
import type { Mod, Instance } from '../../shared/types';
const mr = 'https://api.modrinth.com/v2';
export class Mods {
  constructor(
    private store: Store,
    private secret: (key: string) => Promise<string>,
  ) {}
  async list(id: string): Promise<Mod[]> {
    const root = this.store.dir(id);
    const dir = path.join(root, 'mods');
    await fs.mkdir(dir, { recursive: true });
    const out: Mod[] = [];
    const sources = this.store.get<Record<string, Mod['source']>>('modSources:' + id, {});
    for (const file of await fs.readdir(dir)) {
      if (!/\.jar(?:\.disabled)?$/i.test(file)) continue;
      const full = contained(dir, file);
      const sha = await digest(full);
      let meta: any = {};
      const warnings: string[] = [];
      try {
        const zip = new AdmZip(full);
        safeEntries(zip);
        const entry = zip.getEntry('fabric.mod.json') || zip.getEntry('quilt.mod.json');
        if (entry) {
          const raw = JSON.parse(entry.getData().toString());
          meta = raw.quilt_loader ? { ...raw.quilt_loader, ...raw.quilt_loader.metadata } : raw;
        } else {
          const toml =
            zip.getEntry('META-INF/neoforge.mods.toml') || zip.getEntry('META-INF/mods.toml');
          if (toml) {
            const text = toml.getData().toString();
            meta = {
              id: text.match(/modId\s*=\s*"([^"]+)"/)?.[1],
              name: text.match(/displayName\s*=\s*"([^"]+)"/)?.[1],
              version: text.match(/version\s*=\s*"([^"]+)"/)?.[1],
              authors: [text.match(/authors\s*=\s*"([^"]+)"/)?.[1] || 'Unknown'],
            };
            warnings.push('Forge TOML 의존성 분석 미지원');
          } else warnings.push('알려진 모드 메타데이터 없음');
        }
      } catch {
        warnings.push('JAR 메타데이터를 읽을 수 없음');
      }
      const authors = (Array.isArray(meta.authors) ? meta.authors : []).map((a: any) =>
        typeof a === 'string' ? a : a.name || 'Unknown',
      );
      const deps = Array.isArray(meta.depends)
        ? meta.depends.map((d: any) => d.id)
        : Object.keys(meta.depends || {});
      out.push({
        file,
        id: meta.id || file,
        name: meta.name || meta.id || file,
        version: meta.version || 'Unknown',
        authors,
        enabled: !file.endsWith('.disabled'),
        sha256: sha,
        depends: deps,
        source: sources[sha],
        warnings,
      });
    }
    const enabled = out.filter((m) => m.enabled);
    const known = new Set([
      ...enabled.map((m) => m.id),
      'minecraft',
      'java',
      this.store.instance(id).loader === 'quilt' ? 'quilt_loader' : 'fabricloader',
    ]);
    for (const m of out) {
      if (enabled.filter((n) => n.id === m.id).length > 1) m.warnings.push('동일 모드 ID 중복');
      if (out.filter((n) => n.sha256 === m.sha256).length > 1) m.warnings.push('동일 파일 중복');
      if (m.enabled)
        for (const dep of m.depends)
          if (!known.has(dep)) m.warnings.push('필수 의존성 누락: ' + dep);
    }
    return out;
  }
  async import(id: string, files: string[]) {
    const dir = path.join(this.store.dir(id), 'mods');
    await fs.mkdir(dir, { recursive: true });
    for (const f of files) {
      if (path.extname(f).toLowerCase() !== '.jar') throw Error('JAR 파일만 가져올 수 있습니다.');
      if ((await fs.stat(f)).size > 256 * 1024 ** 2) throw Error('JAR 크기 제한 초과');
      const z = new AdmZip(f);
      safeEntries(z);
      await fs.copyFile(f, contained(dir, path.basename(f)), fs.constants.COPYFILE_EXCL);
    }
    return this.list(id);
  }
  async toggle(id: string, file: string) {
    if (!/\.jar(?:\.disabled)?$/.test(file)) throw Error('JAR 파일명 오류');
    const dir = path.join(this.store.dir(id), 'mods');
    const next = file.endsWith('.disabled') ? file.slice(0, -9) : file + '.disabled';
    await fs.copyFile(contained(dir, file), contained(dir, next), fs.constants.COPYFILE_EXCL);
    await fs.rm(contained(dir, file));
  }
  async remove(id: string, file: string) {
    if (!/\.jar(?:\.disabled)?$/.test(file)) throw Error('JAR 파일명 오류');
    await fs.rm(contained(path.join(this.store.dir(id), 'mods'), file));
  }
  async backup(id: string) {
    const root = this.store.dir(id);
    const zip = new AdmZip();
    const dir = path.join(root, 'mods');
    await fs.mkdir(dir, { recursive: true });
    zip.addLocalFolder(dir);
    await fs.mkdir(path.join(root, 'backups'), { recursive: true });
    const name = new Date().toISOString().replaceAll(':', '-') + '.zip';
    zip.writeZip(path.join(root, 'backups', name));
    return name;
  }
  async restore(id: string, name: string) {
    const root = this.store.dir(id);
    const zip = new AdmZip(contained(path.join(root, 'backups'), name));
    safeEntries(zip);
    const stage = path.join(root, 'restore-' + randomUUID());
    await fs.mkdir(stage);
    try {
      await extract(zip, stage, '', (n) => /\.jar(?:\.disabled)?$/.test(n));
      await this.backup(id);
      const old = path.join(root, 'mods.old');
      await fs.rm(old, { recursive: true, force: true });
      await fs.rename(path.join(root, 'mods'), old);
      try {
        await fs.rename(stage, path.join(root, 'mods'));
      } catch (e) {
        await fs.rename(old, path.join(root, 'mods'));
        throw e;
      }
      await fs.rm(old, { recursive: true });
    } finally {
      await fs.rm(stage, { recursive: true, force: true });
    }
  }
  private async cf(endpoint: string) {
    const key = await this.secret('curseforge');
    if (!key) throw Error('Settings에서 CurseForge API 키를 저장하세요.');
    return json('https://api.curseforge.com/v1' + endpoint, { headers: { 'x-api-key': key } });
  }
  async search(
    provider: string,
    query: string,
    i: Instance | undefined,
    sort = 'relevance',
    category = '',
  ) {
    if (provider === 'modrinth') {
      const facets = [['project_type:mod']];
      if (i) {
        facets.push(['versions:' + i.version]);
        if (i.loader !== 'vanilla') facets.push(['categories:' + i.loader]);
      }
      if (category) facets.push(['categories:' + category]);
      const d = await json(
        mr +
          '/search?' +
          new URLSearchParams({ query, limit: '30', index: sort, facets: JSON.stringify(facets) }),
      );
      return d.hits.map((m: any) => ({
        id: m.project_id,
        title: m.title,
        description: m.description,
        author: m.author,
        downloads: m.downloads,
        icon: m.icon_url,
        provider,
      }));
    }
    const loaderId = { vanilla: 0, forge: 1, fabric: 4, quilt: 5, neoforge: 6 };
    const d = await this.cf(
      '/mods/search?' +
        new URLSearchParams({
          gameId: '432',
          classId: '6',
          searchFilter: query,
          pageSize: '30',
          sortField: sort === 'newest' ? '11' : sort === 'downloads' ? '6' : '2',
          sortOrder: 'desc',
          ...(i ? { gameVersion: i.version, modLoaderType: String(loaderId[i.loader]) } : {}),
        }),
    );
    return d.data.map((m: any) => ({
      id: String(m.id),
      title: m.name,
      description: m.summary,
      author: m.authors.map((a: any) => a.name).join(', '),
      downloads: m.downloadCount,
      icon: m.logo?.thumbnailUrl,
      provider,
    }));
  }
  async detail(provider: string, project: string, i: Instance) {
    if (provider === 'modrinth') {
      const [p, v] = await Promise.all([
        json(mr + '/project/' + encodeURIComponent(project)),
        json(
          mr +
            '/project/' +
            encodeURIComponent(project) +
            '/version?' +
            new URLSearchParams({
              game_versions: JSON.stringify([i.version]),
              loaders: JSON.stringify([i.loader]),
            }),
        ),
      ]);
      return {
        project: p,
        versions: v.map((v: any) => ({
          id: v.id,
          name: v.name,
          version: v.version_number,
          published: v.date_published,
        })),
        license: p.license?.name,
        body: p.body,
        url: 'https://modrinth.com/mod/' + p.slug,
      };
    }
    const [p, v] = await Promise.all([
      this.cf('/mods/' + project),
      this.cf(
        `/mods/${project}/files?gameVersion=${encodeURIComponent(i.version)}&modLoaderType=${{ vanilla: 0, forge: 1, fabric: 4, quilt: 5, neoforge: 6 }[i.loader]}`,
      ),
    ]);
    return {
      project: p.data,
      versions: v.data.map((f: any) => ({
        id: String(f.id),
        name: f.displayName,
        version: f.fileName,
      })),
      license: 'CurseForge 프로젝트의 라이선스를 확인하세요.',
      body: p.data.summary,
      url: p.data.links.websiteUrl,
    };
  }
  async install(
    id: string,
    provider: string,
    project: string,
    versionId: string,
    signal: AbortSignal,
  ) {
    const i = this.store.instance(id);
    if (i.loader === 'vanilla') throw Error('모드를 설치하려면 로더 인스턴스를 선택하세요.');
    const stage = path.join(this.store.dir(id), 'mod-stage-' + randomUUID());
    await fs.mkdir(stage, { recursive: true });
    const plan: { file: string; sha: string; source: NonNullable<Mod['source']> }[] = [];
    const seen = new Set<string>();
    const active = new Set<string>();
    const resolveMR = async (pid: string, vid?: string): Promise<void> => {
      const key = vid || pid;
      if (active.has(key)) throw Error('순환 모드 의존성');
      if (seen.has(key)) return;
      active.add(key);
      let v = vid
        ? await json(mr + '/version/' + encodeURIComponent(vid))
        : (
            await json(
              mr +
                '/project/' +
                encodeURIComponent(pid) +
                '/version?' +
                new URLSearchParams({
                  game_versions: JSON.stringify([i.version]),
                  loaders: JSON.stringify([i.loader]),
                }),
            )
          )[0];
      if (!v) throw Error('호환 버전 없음: ' + pid);
      if (!v.game_versions.includes(i.version) || !v.loaders.includes(i.loader))
        throw Error('호환되지 않는 모드 버전');
      for (const dep of v.dependencies || [])
        if (dep.dependency_type === 'required') {
          if (!dep.version_id && !dep.project_id)
            throw Error('수동 설치가 필요한 의존성: ' + dep.file_name);
          await resolveMR(dep.project_id, dep.version_id);
        }
      const f = v.files.find((f: any) => f.primary) || v.files[0];
      if (!f?.filename.endsWith('.jar')) throw Error('JAR 모드 파일이 아닙니다.');
      const dest = contained(stage, f.filename);
      await download(f.url, dest, { algorithm: 'sha512', value: f.hashes.sha512 }, signal);
      const sha = await digest(dest);
      plan.push({
        file: f.filename,
        sha,
        source: { provider: 'modrinth', project: v.project_id, version: v.id },
      });
      seen.add(key);
      active.delete(key);
    };
    const resolveCF = async (pid: string, vid?: string): Promise<void> => {
      const key = pid;
      if (active.has(key)) throw Error('순환 모드 의존성');
      if (seen.has(key)) return;
      active.add(key);
      const files = vid
        ? null
        : await this.cf(
            `/mods/${pid}/files?gameVersion=${encodeURIComponent(i.version)}&modLoaderType=${{ vanilla: 0, forge: 1, fabric: 4, quilt: 5, neoforge: 6 }[i.loader]}`,
          );
      const f = vid ? (await this.cf(`/mods/${pid}/files/${vid}`)).data : files.data[0];
      if (!f || !f.gameVersions.includes(i.version)) throw Error('호환 버전 없음');
      for (const dep of f.dependencies || [])
        if (dep.relationType === 3) await resolveCF(String(dep.modId));
      if (!f.downloadUrl)
        throw Error(
          '제작자가 외부 런처 다운로드를 허용하지 않았습니다. CurseForge에서 직접 받으세요.',
        );
      const h = f.hashes.find((h: any) => h.algo === 1);
      if (!h) throw Error('공식 SHA-1 해시가 없습니다.');
      if (!f.fileName.endsWith('.jar')) throw Error('JAR 파일이 아닙니다.');
      const dest = contained(stage, f.fileName);
      await download(f.downloadUrl, dest, { algorithm: 'sha1', value: h.value }, signal);
      plan.push({
        file: f.fileName,
        sha: await digest(dest),
        source: { provider: 'curseforge', project: pid, version: String(f.id) },
      });
      seen.add(key);
      active.delete(key);
    };
    try {
      if (provider === 'modrinth') await resolveMR(project, versionId);
      else await resolveCF(project, versionId);
      const dir = path.join(this.store.dir(id), 'mods');
      await fs.mkdir(dir, { recursive: true });
      const installed = await this.list(id);
      const oldSources = this.store.get<Record<string, Mod['source']>>('modSources:' + id, {});
      const sources = { ...oldSources };
      const replaced = installed.filter(
        (m) =>
          m.source &&
          plan.some(
            (p) =>
              p.source.project === m.source!.project && p.source.provider === m.source!.provider,
          ),
      );
      await this.backup(id);
      const added: string[] = [];
      const removed: Mod[] = [];
      try {
        for (const m of replaced) {
          await fs.rename(contained(dir, m.file), contained(stage, 'old-' + m.file));
          removed.push(m);
        }
        for (const p of plan) {
          const existing = installed.find((m) => m.sha256 === p.sha);
          if (existing && !replaced.includes(existing)) continue;
          const dest = contained(dir, p.file);
          await fs.copyFile(contained(stage, p.file), dest, fs.constants.COPYFILE_EXCL);
          added.push(dest);
          sources[p.sha] = p.source;
        }
        this.store.set('modSources:' + id, sources);
      } catch (e) {
        for (const f of added) await fs.rm(f, { force: true });
        for (const m of removed)
          await fs.rename(contained(stage, 'old-' + m.file), contained(dir, m.file));
        throw e;
      }
    } finally {
      await fs.rm(stage, { recursive: true, force: true });
    }
    return this.list(id);
  }
  async updates(id: string) {
    const i = this.store.instance(id);
    const mods = (await this.list(id)).filter((m) => m.source);
    const out = [];
    for (const m of mods) {
      const detail = await this.detail(m.source!.provider, m.source!.project, i);
      if (detail.versions[0] && String(detail.versions[0].id) !== m.source!.version)
        out.push({ file: m.file, name: m.name, source: m.source, latest: detail.versions[0] });
    }
    return out;
  }
}
