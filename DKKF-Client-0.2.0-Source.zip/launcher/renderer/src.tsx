import React, { useEffect, useState, createContext, useContext } from 'react';
import { createRoot } from 'react-dom/client';
import type { Snapshot, Instance, Loader, Mod, Progress } from '../../shared/types';
import './style.css';
import target from '../../shared/target.json';
type State = Snapshot & { packs: string[]; activeAccount: string };
type Ctx = {
  s: State;
  run: <T = any>(method: string, args?: unknown) => Promise<T | undefined>;
  reload: () => Promise<void>;
  toast: (s: string) => void;
  epoch: number;
  pending: boolean;
};
const Context = createContext<Ctx>(null!);
const useApp = () => useContext(Context);
const pages = [
  ['Home', '홈'],
  ['Instances', '인스턴스'],
  ['Mod Hub', '모드 탐색'],
  ['My Mods', '내 모드'],
  ['Modpacks', '모드팩'],
  ['Upload Center', '게시 센터'],
  ['Update Center', '업데이트'],
  ['Settings', '설정'],
  ['Account', '계정'],
];
function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    Home: (
      <>
        <path d="m3 11 9-8 9 8" />
        <path d="M5 10v11h5v-7h4v7h5V10" />
      </>
    ),
    Instances: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="2" />
        <rect x="14" y="3" width="7" height="7" rx="2" />
        <rect x="3" y="14" width="7" height="7" rx="2" />
        <rect x="14" y="14" width="7" height="7" rx="2" />
      </>
    ),
    'Mod Hub': (
      <>
        <path d="m12 3 9 5v9l-9 5-9-5V8Z" />
        <path d="m3 8 9 5 9-5M12 13v9" />
      </>
    ),
    'My Mods': (
      <>
        <path d="M4 5h16v15H4zM8 5V3h8v2M8 10h8M8 14h5" />
      </>
    ),
    Modpacks: (
      <>
        <rect x="3" y="7" width="18" height="14" rx="2" />
        <path d="m7 7 2-4h6l2 4M3 12h18M10 12v3h4v-3" />
      </>
    ),
    'Upload Center': (
      <>
        <path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6" />
      </>
    ),
    'Update Center': (
      <>
        <path d="M20 8a8 8 0 1 0 0 9M20 3v6h-6M12 8v5l3 2" />
      </>
    ),
    Settings: (
      <>
        <path d="m9 3-1 3-3 1-2 4 2 3v4l4 2 3-1 3 1 4-2v-4l2-3-2-4-3-1-1-3Z" />
        <circle cx="12" cy="12" r="3" />
      </>
    ),
    Account: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 22v-3a8 8 0 0 1 16 0v3" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name] || <path d="m8 5 10 7-10 7Z" />}
    </svg>
  );
}
function App() {
  const [s, setS] = useState<State>();
  const [page, setPage] = useState('Home');
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [progress, setProgress] = useState<Progress>();
  const [logs, setLogs] = useState('');
  const [epoch, setEpoch] = useState(0);
  const [pending, setPending] = useState(false);
  const [showLogs, setShowLogs] = useState(false);
  const reload = async () => {
    const data = await window.dkkf.call<State>('state');
    setS(data);
    setEpoch((n) => n + 1);
  };
  useEffect(() => {
    if (!window.dkkf) {
      setError('Electron 연결이 없습니다. DKKF Client 데스크톱 앱으로 실행하세요.');
      return;
    }
    void reload().catch((e) => setError(e.message));
    return window.dkkf.onEvent((e) => {
      if (e.type === 'state') {
        setS(e.data);
        setEpoch((n) => n + 1);
        if (!e.data.busy) setProgress(undefined);
      }
      if (e.type === 'progress') setProgress(e.data);
      if (e.type === 'notice') setToast(e.data);
      if (e.type === 'log') setLogs((l) => (l + e.data).slice(-70000));
      if (e.type === 'update' && e.data.status === 'available')
        setToast('새 런처 버전이 있습니다. 업데이트 센터에서 확인하세요.');
    });
  }, []);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 7000);
    return () => clearTimeout(t);
  }, [toast]);
  const run = async <T,>(method: string, args?: unknown): Promise<T | undefined> => {
    setPending(true);
    try {
      const r = await window.dkkf.call<T>(method, args);
      await reload();
      return r;
    } catch (e) {
      setToast((e as Error).message);
      return undefined;
    } finally {
      setPending(false);
    }
  };
  if (!s)
    return (
      <div className="boot">
        <div className="brandmark">D</div>
        <h1>DKKF CLIENT</h1>
        <p>{error || '보안 저장소를 준비하고 있습니다…'}</p>
      </div>
    );
  const selected = s.instances.find((i) => i.id === s.selected);
  const account = s.accounts.find((a) => a.id === s.activeAccount);
  return (
    <Context.Provider value={{ s, run, reload, toast: setToast, epoch, pending }}>
      <div className="app">
        <aside>
          <a className="brand" onClick={() => setPage('Home')}>
            <div className="brandmark">D</div>
            <div>
              <b>
                DKKF<span>CLIENT</span>
              </b>
              <small>NEON EDITION</small>
            </div>
          </a>
          <div className="navlabel">WORKSPACE</div>
          <nav>
            {pages.map(([p, k], n) => (
              <React.Fragment key={p}>
                {n === 5 && <div className="navlabel">MANAGEMENT</div>}
                <button className={page === p ? 'active' : ''} onClick={() => setPage(p)}>
                  <Icon name={p} />
                  <span>{p}</span>
                  {page === p && <i />}
                </button>
              </React.Fragment>
            ))}
          </nav>
          <div className="sidebar-bottom">
            <div className="channel">
              <i className="dot" /> {s.settings.channel.toUpperCase()} <span>v{s.version}</span>
            </div>
            <button className="profile" onClick={() => setPage('Account')}>
              <div className="avatar">{account?.name.slice(0, 1).toUpperCase() || '?'}</div>
              <div>
                <b>{account?.name || '계정 연결'}</b>
                <small>{account ? 'Microsoft 계정' : 'Microsoft 로그인 필요'}</small>
              </div>
              <span>↗</span>
            </button>
          </div>
        </aside>
        <div className="workspace">
          <header>
            <div className="crumb">
              DKKF Client <span>/</span> <b>{page}</b>
            </div>
            <div className="header-right">
              <span className={'status ' + (s.running ? 'cyan' : '')}>
                <i className="dot" />
                {s.running ? 'GAME RUNNING' : s.busy ? 'WORKING' : 'READY TO PLAY'}
              </span>
              <button
                className="iconbutton"
                title="실행 로그"
                onClick={() => setShowLogs(!showLogs)}
              >
                ⌘
              </button>
            </div>
          </header>
          <main key={page}>
            <div className="pageheading">
              <div>
                <div className="eyebrow">YOUR GAME. YOUR WAY.</div>
                <h1>
                  {page === 'Home' ? `반가워요${account ? ', ' + account.name + '님' : ''}.` : page}
                </h1>
                <p>
                  {page === 'Home'
                    ? '다음 모험을 시작할 준비가 되었나요?'
                    : pages.find((p) => p[0] === page)?.[1] + '를 관리하세요.'}
                </p>
              </div>
              {page !== 'Settings' && page !== 'Account' && (
                <div className="instance-picker">
                  <small>ACTIVE INSTANCE</small>
                  <select
                    value={s.selected || ''}
                    onChange={(e) => void run('instances.select', e.target.value)}
                  >
                    <option value="" disabled>
                      인스턴스 선택
                    </option>
                    {s.instances.map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            {page === 'Home' && <Home go={setPage} selected={selected} />}
            {page === 'Instances' && <Instances />}
            {page === 'Mod Hub' && <Hub selected={selected} />}
            {page === 'My Mods' && <MyMods selected={selected} />}
            {page === 'Modpacks' && <Modpacks />}
            {page === 'Upload Center' && <Upload selected={selected} />}
            {page === 'Update Center' && <Updates />}
            {page === 'Settings' && <Settings />}
            {page === 'Account' && <Account />}
          </main>
          <footer>
            <div className="footer-status">
              <span>
                <i className="dot" /> DKKF Client <em>Neon Edition</em>
              </span>
              <span>
                {s.running ? '게임 실행 중' : s.busy ? '작업 진행 중' : '모험을 위한 나만의 공간'}
              </span>
            </div>
            <p className="product-disclaimer">
              NOT AN OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG OR
              MICROSOFT.
            </p>
          </footer>
        </div>
      </div>
      {progress && (
        <div className="progress-dock">
          <div>
            <b>{progress.message}</b>
            <button onClick={() => void run('task.cancel')}>취소</button>
          </div>
          <progress
            max={progress.total || 1}
            value={progress.total ? progress.current : undefined}
          />
          <small>
            {progress.total
              ? Math.min(100, Math.floor((progress.current / progress.total) * 100)) + '%'
              : '처리 중…'}
          </small>
        </div>
      )}
      {toast && (
        <div className="toast" role="status">
          <span>{toast}</span>
          <button onClick={() => setToast('')}>×</button>
        </div>
      )}
      {showLogs && (
        <Modal title="실행 로그" close={() => setShowLogs(false)}>
          <pre className="logs">{logs || '아직 게임 실행 로그가 없습니다.'}</pre>
          <button onClick={() => void run('settings.data')}>로그 폴더 열기</button>
        </Modal>
      )}
    </Context.Provider>
  );
}
function Empty({
  title,
  body,
  children,
}: {
  title: string;
  body: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="empty">
      <div className="empty-icon">◇</div>
      <h3>{title}</h3>
      <p>{body}</p>
      {children}
    </div>
  );
}
function Modal({
  title,
  close,
  children,
}: {
  title: string;
  close: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="modal-backdrop" onClick={close}>
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-head">
          <h2>{title}</h2>
          <button onClick={close} aria-label="닫기">
            ×
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}
function Home({ go, selected }: { go: (p: string) => void; selected?: Instance }) {
  const { s, run, pending } = useApp();
  const [history, setHistory] = useState<any[]>([]);
  useEffect(() => {
    window.dkkf
      .call<any[]>('history')
      .then(setHistory)
      .catch(() => {});
  }, [s.running]);
  return (
    <>
      <section className="hero">
        <div className="hero-grid" />
        <div className="terrain">
          <div className="voxel v1" />
          <div className="voxel v2" />
          <div className="voxel v3" />
          <div className="orbit" />
        </div>
        <div className="hero-content">
          <div className="pill">
            MINECRAFT JAVA EDITION <i>✦</i>
          </div>
          <h2>
            새로운 세상,
            <br />
            <span>나만의 플레이.</span>
          </h2>
          <p>
            버전부터 모드까지, 당신의 방식대로.
            <br />
            DKKF와 함께 다음 모험을 시작하세요.
          </p>
          <div className="hero-actions">
            <button
              className="primary large"
              disabled={pending || s.busy || !!s.running}
              onClick={() =>
                selected
                  ? void run(selected.installed ? 'game.launch' : 'game.install', selected.id)
                  : go('Instances')
              }
            >
              <Icon name="play" size={18} />
              {selected ? (selected.installed ? '게임 실행' : '게임 설치') : '인스턴스 만들기'}
            </button>
            <button className="glass" onClick={() => go('Instances')}>
              인스턴스 관리 ↗
            </button>
          </div>
          <div className="hero-meta">
            <i className="dot" />
            {selected
              ? `${selected.version} · ${selected.loader.toUpperCase()} · ${selected.ram / 1024} GB RAM`
              : '인스턴스를 만든 뒤 Microsoft 계정을 연결하세요.'}
          </div>
        </div>
        <span className="hero-corner">DKKF / NEON_01</span>
      </section>
      <div className="stats">
        <Stat
          label="MY INSTANCES"
          value={String(s.instances.length)}
          sub="독립된 게임 환경"
          icon="Instances"
        />
        <Stat
          label="ACTIVE LOADER"
          value={selected?.loader.toUpperCase() || '—'}
          sub={selected?.loaderVersion || '선택된 로더 없음'}
          icon="Mod Hub"
        />
        <Stat
          label="MEMORY"
          value={selected ? selected.ram / 1024 + ' GB' : '—'}
          sub="인스턴스별 메모리 할당"
          icon="Settings"
        />
      </div>
      <div className="twocol">
        <section className="panel">
          <div className="sectiontitle">
            <h2>바로 이어서 플레이</h2>
            <button className="textbutton" onClick={() => go('Instances')}>
              모두 보기 ↗
            </button>
          </div>
          {s.instances.length ? (
            s.instances.slice(0, 3).map((i) => (
              <div className="instance-row" key={i.id}>
                <div className={'game-icon ' + i.loader}>
                  <Icon name="Mod Hub" size={25} />
                </div>
                <div>
                  <b>{i.name}</b>
                  <small>
                    {i.version} · {i.loader}
                  </small>
                </div>
                <span className="tag">{i.installed ? 'INSTALLED' : 'NEW'}</span>
                <button
                  className="square"
                  disabled={s.busy || !!s.running || pending}
                  title={i.installed ? '실행' : '설치'}
                  onClick={() => void run(i.installed ? 'game.launch' : 'game.install', i.id)}
                >
                  ▶
                </button>
              </div>
            ))
          ) : (
            <Empty
              title="첫 번째 세계를 준비하세요"
              body="Minecraft 버전과 로더를 자유롭게 선택할 수 있어요."
            />
          )}
        </section>
        <section className="panel discover">
          <span className="eyebrow">MAKE IT YOURS</span>
          <h2>플레이에 가능성을 더하다.</h2>
          <p>
            Modrinth와 CurseForge에서
            <br />내 버전에 맞는 모드를 찾아보세요.
          </p>
          <div className="mod-shapes">
            <span>◈</span>
            <span>⌘</span>
            <span>⬡</span>
          </div>
          <button className="secondary" onClick={() => go('Mod Hub')}>
            Mod Hub 탐색 ↗
          </button>
        </section>
      </div>
      <section className="panel">
        <div className="sectiontitle">
          <h2>최근 플레이 기록</h2>
          <span className="muted">LOCAL HISTORY</span>
        </div>
        {history.length ? (
          history.slice(0, 5).map((h, n) => (
            <div className="history" key={n}>
              <b>{s.instances.find((i) => i.id === h[0])?.name || h[0]}</b>
              <span>{new Date(h[1]).toLocaleString('ko-KR')}</span>
              <span>종료 코드 {h[2] ?? '—'}</span>
            </div>
          ))
        ) : (
          <p className="muted">실제로 실행을 완료한 게임의 기록이 여기에 표시됩니다.</p>
        )}
      </section>
      <div className="notice-inline">
        안내 · Microsoft 앱 등록과 업데이트 배포 설정은 Settings에서 구성할 수 있습니다. 비공식
        Minecraft 런처이며 Mojang 또는 Microsoft와 제휴하지 않습니다.
      </div>
    </>
  );
}
function Stat({
  label,
  value,
  sub,
  icon,
}: {
  label: string;
  value: string;
  sub: string;
  icon: string;
}) {
  return (
    <div className="stat">
      <div>
        <small>{label}</small>
        <h2>{value}</h2>
        <p>{sub}</p>
      </div>
      <div className="stat-icon">
        <Icon name={icon} size={25} />
      </div>
    </div>
  );
}
function Instances() {
  const { s, run, pending } = useApp();
  const [create, setCreate] = useState(false);
  const [edit, setEdit] = useState<Instance>();
  return (
    <>
      <div className="toolbar">
        <span className="muted">{s.instances.length}개의 독립된 환경</span>
        <button className="primary" onClick={() => setCreate(true)}>
          ＋ 새 인스턴스
        </button>
      </div>
      {!s.instances.length ? (
        <Empty
          title="모험의 시작점을 만드세요"
          body="공식 Minecraft 파일로 버전마다 독립된 인스턴스를 설치합니다."
        >
          <button onClick={() => setCreate(true)}>인스턴스 만들기</button>
        </Empty>
      ) : (
        <div className="cards">
          {s.instances.map((i) => (
            <section
              className={'panel instance-card ' + (i.id === s.selected ? 'selected' : '')}
              key={i.id}
            >
              <div className="card-top">
                <div className={'game-icon ' + i.loader}>
                  <Icon name="Mod Hub" size={30} />
                </div>
                <span className="tag">{i.loader.toUpperCase()}</span>
              </div>
              <h2>{i.name}</h2>
              <p>Minecraft {i.version}</p>
              <div className="specs">
                <span>{i.ram / 1024} GB RAM</span>
                <span>{i.installed ? '설치됨' : '설치 대기'}</span>
              </div>
              <div className="button-row">
                <button
                  className="primary"
                  disabled={s.busy || pending || !!s.running}
                  onClick={() => void run(i.installed ? 'game.launch' : 'game.install', i.id)}
                >
                  {i.installed ? '▶ 실행' : '↓ 설치'}
                </button>
                <button
                  disabled={s.selected === i.id}
                  onClick={() => void run('instances.select', i.id)}
                >
                  {s.selected === i.id ? '선택됨' : '선택'}
                </button>
              </div>
              <div className="card-tools">
                <button disabled={s.busy || !!s.running} onClick={() => setEdit(i)}>
                  편집
                </button>
                <button
                  disabled={s.busy || !!s.running}
                  onClick={() => void run('instances.clone', i.id)}
                >
                  복제
                </button>
                <button onClick={() => void run('instances.folder', i.id)}>폴더</button>
                <button
                  className="danger"
                  disabled={s.busy || !!s.running}
                  onClick={() => void run('instances.delete', i.id)}
                >
                  삭제
                </button>
              </div>
            </section>
          ))}
        </div>
      )}
      {create && <CreateInstance close={() => setCreate(false)} />}{' '}
      {edit && <EditInstance i={edit} close={() => setEdit(undefined)} />}
    </>
  );
}
function CreateInstance({ close }: { close: () => void }) {
  const { s, run, pending, toast } = useApp();
  const [name, setName] = useState('나의 Minecraft');
  const [versions, setVersions] = useState<any[]>([]);
  const [version, setVersion] = useState('');
  const [snap, setSnap] = useState(false);
  const [loader, setLoader] = useState<Loader>('fabric');
  const [loaders, setLoaders] = useState<any[]>([]);
  const [lv, setLV] = useState('');
  const [ram, setRam] = useState(s.settings.ram);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  useEffect(() => {
    window.dkkf
      .call('versions')
      .then((d) => {
        setVersions(d.versions);
        setVersion(
          d.versions.some((v: any) => v.id === target.minecraft)
            ? target.minecraft
            : d.latest.release,
        );
      })
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    setLoaders([]);
    setLV('');
    if (!version || loader === 'vanilla') return;
    let alive = true;
    setLoading(true);
    window.dkkf
      .call('loaders', { version, loader })
      .then((d) => {
        if (alive) {
          setLoaders(d);
          setLV(d[0]?.version || '');
        }
      })
      .catch((e) => alive && setErr(e.message))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [version, loader]);
  return (
    <Modal title="새 인스턴스" close={close}>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          const i = await run('instances.create', {
            name,
            version,
            loader,
            loaderVersion: lv,
            ram,
          });
          if (i) close();
        }}
      >
        <label>
          이름
          <input value={name} onChange={(e) => setName(e.target.value)} maxLength={70} required />
        </label>
        <label className="check">
          <input type="checkbox" checked={snap} onChange={(e) => setSnap(e.target.checked)} />
          스냅샷·과거 버전 포함
        </label>
        <div className="formgrid">
          <label>
            Minecraft 버전
            <select
              aria-label="Minecraft 버전"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              required
            >
              {versions
                .filter((v) => snap || v.type === 'release')
                .map((v) => (
                  <option key={v.id}>{v.id}</option>
                ))}
            </select>
          </label>
          <label>
            모드 로더
            <select
              aria-label="모드 로더"
              value={loader}
              onChange={(e) => setLoader(e.target.value as Loader)}
            >
              {['vanilla', 'fabric', 'forge', 'neoforge', 'quilt'].map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </label>
        </div>
        {loader !== 'vanilla' && (
          <label>
            호환 로더 버전
            <select value={lv} onChange={(e) => setLV(e.target.value)} required>
              <option value="">{loading ? '조회 중…' : '버전 선택'}</option>
              {loaders.map((l) => (
                <option key={l.version}>{l.version}</option>
              ))}
            </select>
          </label>
        )}
        <label>
          RAM: {(ram / 1024).toFixed(1)} GB
          <input
            type="range"
            min="1024"
            max="32768"
            step="512"
            value={ram}
            onChange={(e) => setRam(Number(e.target.value))}
          />
        </label>
        {err && <p className="error">{err}</p>}
        <p className="hint">
          생성 후 설치 버튼으로 공식 게임 파일을 다운로드합니다. 버전에 맞는 Java는 Settings에서
          지정하세요.
        </p>
        <button
          className="primary full"
          disabled={pending || loading || !version || (loader !== 'vanilla' && !lv)}
        >
          인스턴스 생성
        </button>
      </form>
    </Modal>
  );
}
function EditInstance({ i, close }: { i: Instance; close: () => void }) {
  const { run, pending } = useApp();
  const [name, setName] = useState(i.name);
  const [ram, setRam] = useState(i.ram);
  return (
    <Modal title="인스턴스 편집" close={close}>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          await run('instances.edit', { id: i.id, name, ram });
          close();
        }}
      >
        <label>
          이름
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </label>
        <label>
          RAM: {ram / 1024} GB
          <input
            type="range"
            min="1024"
            max="32768"
            step="512"
            value={ram}
            onChange={(e) => setRam(Number(e.target.value))}
          />
        </label>
        <button className="primary full" disabled={pending}>
          저장
        </button>
      </form>
    </Modal>
  );
}
type Hit = {
  id: string;
  title: string;
  description: string;
  author: string;
  downloads: number;
  icon?: string;
  provider: string;
};
function Hub({ selected }: { selected?: Instance }) {
  const { run, s, pending } = useApp();
  const [provider, setProvider] = useState('modrinth');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('relevance');
  const [category, setCategory] = useState('');
  const [hits, setHits] = useState<Hit[]>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [detail, setDetail] = useState<Hit>();
  const search = async () => {
    setLoading(true);
    setError('');
    try {
      const d = await window.dkkf.call('mods.search', {
        provider,
        query,
        sort,
        category,
        instance: selected?.id,
      });
      setHits(d);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void search();
  }, [provider, sort, selected?.id, category]);
  return (
    <>
      <div className="platforms">
        <button
          className={provider === 'modrinth' ? 'chosen' : ''}
          onClick={() => setProvider('modrinth')}
        >
          <span className="platform-dot mr" />
          Modrinth
        </button>
        <button
          className={provider === 'curseforge' ? 'chosen' : ''}
          onClick={() => setProvider('curseforge')}
        >
          <span className="platform-dot cf" />
          CurseForge
        </button>
        <span className="muted">공식 API · 원본 파일 검증</span>
      </div>
      <form
        className="searchbar"
        onSubmit={(e) => {
          e.preventDefault();
          void search();
        }}
      >
        <span>⌕</span>
        <input
          aria-label="모드 검색"
          placeholder="당신의 다음 모드를 찾아보세요…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="primary" disabled={loading}>
          검색
        </button>
      </form>
      <div className="toolbar">
        <div className="chips">
          <span className="tag">{selected?.version || '모든 버전'}</span>
          <span className="tag">{selected?.loader.toUpperCase() || '모든 로더'}</span>
          <span className="muted">{hits?.length ?? 0}개 표시</span>
        </div>
        <div className="button-row">
          {provider === 'modrinth' && (
            <select
              aria-label="카테고리"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">모든 카테고리</option>
              {[
                'optimization',
                'utility',
                'adventure',
                'technology',
                'magic',
                'decoration',
                'worldgen',
              ].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          )}
          <select aria-label="정렬" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="relevance">인기순</option>
            <option value="downloads">다운로드순</option>
            <option value="newest">최신순</option>
          </select>
        </div>
      </div>
      {error ? (
        <Empty title="검색을 완료하지 못했습니다" body={error}>
          <button onClick={() => void search()}>다시 시도</button>
        </Empty>
      ) : loading ? (
        <div className="cards">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div className="skeleton" key={n} />
          ))}
        </div>
      ) : hits?.length ? (
        <div className="cards modcards">
          {hits.map((h) => (
            <button className="panel modcard" key={h.id} onClick={() => setDetail(h)}>
              <div className="card-top">
                {h.icon ? (
                  <img src={h.icon} alt="" referrerPolicy="no-referrer" />
                ) : (
                  <div className="game-icon">
                    <Icon name="Mod Hub" size={30} />
                  </div>
                )}
                <span className="tag">{h.provider}</span>
              </div>
              <h3>{h.title}</h3>
              <small>by {h.author}</small>
              <p>{h.description}</p>
              <div className="mod-bottom">
                <span>
                  ↓ {Intl.NumberFormat('en', { notation: 'compact' }).format(h.downloads)}
                </span>
                <b>자세히 ↗</b>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <Empty title="검색 결과가 없습니다" body="다른 검색어나 인스턴스 버전을 선택하세요." />
      )}
      {detail && <ModDetail hit={detail} selected={selected} close={() => setDetail(undefined)} />}
    </>
  );
}
function ModDetail({ hit, selected, close }: { hit: Hit; selected?: Instance; close: () => void }) {
  const { run, s, pending } = useApp();
  const [d, setD] = useState<any>();
  const [v, setV] = useState('');
  const [err, setErr] = useState('');
  useEffect(() => {
    if (!selected) return;
    window.dkkf
      .call('mods.detail', { provider: hit.provider, project: hit.id, instance: selected.id })
      .then((d) => {
        setD(d);
        setV(d.versions[0]?.id || '');
      })
      .catch((e) => setErr(e.message));
  }, [hit.id, selected?.id]);
  return (
    <Modal title={hit.title} close={close}>
      <p>{hit.description}</p>
      <p className="muted">제작자 · {hit.author}</p>
      {!selected ? (
        <p className="error">호환성을 확인하려면 인스턴스를 선택하세요.</p>
      ) : err ? (
        <p className="error">{err}</p>
      ) : !d ? (
        <p>호환 버전 조회 중…</p>
      ) : (
        <>
          <p>라이선스 · {d.license || '프로젝트 페이지에서 확인'}</p>
          <button className="textbutton" onClick={() => void run('external', d.url)}>
            공식 프로젝트 페이지 ↗
          </button>
          <label>
            설치할 버전
            <select value={v} onChange={(e) => setV(e.target.value)}>
              {!d.versions.length && <option value="">호환 버전 없음</option>}
              {d.versions.map((x: any) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </select>
          </label>
          <div className="hint">
            외부 모드는 임의 코드를 실행할 수 있습니다. 필수 의존성을 함께 설치하며 파일 해시를
            검증합니다.
          </div>
          <button
            className="primary full"
            disabled={!v || s.busy || !!s.running || pending}
            onClick={async () => {
              const r = await run('mods.install', {
                id: selected!.id,
                provider: hit.provider,
                project: hit.id,
                version: v,
              });
              if (r) close();
            }}
          >
            ↓ 모드 설치
          </button>
        </>
      )}
    </Modal>
  );
}
function MyMods({ selected }: { selected?: Instance }) {
  const { s, run, epoch, pending, toast } = useApp();
  const [mods, setMods] = useState<Mod[]>([]);
  const [error, setError] = useState('');
  const [backups, setBackups] = useState<string[]>();
  const [updates, setUpdates] = useState<any[]>();
  useEffect(() => {
    setError('');
    if (selected)
      window.dkkf
        .call<Mod[]>('mods.list', selected.id)
        .then(setMods)
        .catch((e) => setError(e.message));
  }, [selected?.id, epoch]);
  if (!selected)
    return (
      <Empty title="인스턴스를 선택하세요" body="인스턴스마다 모드를 독립적으로 관리합니다." />
    );
  const disabled = s.busy || !!s.running || pending;
  return (
    <>
      <div className="toolbar">
        <span className="muted">
          {mods.filter((m) => m.enabled).length} 활성 · {mods.length}개 파일
        </span>
        <div className="button-row">
          <button
            disabled={
              disabled || selected.version !== target.minecraft || selected.loader !== 'fabric'
            }
            title={`Minecraft ${target.minecraft} Fabric 전용 · F8 편집 / F9 프로필`}
            onClick={async () => {
              const r = await run('core.install', selected.id);
              if (r) toast('DKKF HUD 코어 설치 완료. F8: HUD 편집 / F9: 프로필 전환');
            }}
          >
            DKKF HUD 설치
          </button>
          <button
            disabled={disabled}
            onClick={async () => {
              const r = await run('mods.updates', selected.id);
              if (r) setUpdates(r);
            }}
          >
            업데이트 확인
          </button>
          <button
            disabled={disabled}
            onClick={async () => {
              const name = await run('mods.backup', selected.id);
              if (name) toast('백업 완료: ' + name);
            }}
          >
            백업
          </button>
          <button
            disabled={disabled}
            onClick={async () => setBackups(await run('mods.backups', selected.id))}
          >
            복원
          </button>
          <button
            className="primary"
            disabled={disabled}
            onClick={() => void run('mods.import', selected.id)}
          >
            ＋ JAR 가져오기
          </button>
        </div>
      </div>
      <div className="notice-inline">
        JAR 파일은 신뢰할 수 있는 제작자에게서 받으세요. 누락 의존성·동일 ID/해시 중복을 표시하며,
        버전 범위 충돌의 완전한 분석은 지원하지 않습니다.
      </div>
      {error && <p className="error">{error}</p>}
      {mods.length ? (
        <div className="panel tablepanel">
          <table>
            <thead>
              <tr>
                <th>모드</th>
                <th>버전 / 제작자</th>
                <th>검사</th>
                <th>상태</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {mods.map((m) => (
                <tr key={m.file}>
                  <td>
                    <b>{m.name}</b>
                    <small>{m.file}</small>
                  </td>
                  <td>
                    {m.version}
                    <small>{m.authors.join(', ') || '알 수 없음'}</small>
                  </td>
                  <td>
                    {m.warnings.length ? (
                      <span className="warning" title={m.warnings.join('\n')}>
                        {m.warnings.join(' · ')}
                      </span>
                    ) : (
                      <span className="muted">기본 검사 통과</span>
                    )}
                  </td>
                  <td>
                    <button
                      className={'toggle ' + (m.enabled ? 'on' : '')}
                      aria-label={m.enabled ? '비활성화' : '활성화'}
                      disabled={disabled}
                      onClick={() => void run('mods.toggle', { id: selected.id, file: m.file })}
                    >
                      <i />
                    </button>
                  </td>
                  <td>
                    <button
                      className="danger"
                      disabled={disabled}
                      onClick={() => void run('mods.remove', { id: selected.id, file: m.file })}
                    >
                      삭제
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Empty
          title="아직 설치된 모드가 없습니다"
          body="Mod Hub에서 검색하거나 로컬 JAR를 가져오세요."
        />
      )}
      {backups && (
        <Modal title="모드 백업 복원" close={() => setBackups(undefined)}>
          {backups.length ? (
            backups.map((b) => (
              <button
                className="backup-item"
                key={b}
                disabled={disabled}
                onClick={async () => {
                  await run('mods.restore', { id: selected.id, name: b });
                  setBackups(undefined);
                }}
              >
                {b} ↶
              </button>
            ))
          ) : (
            <p>백업이 없습니다.</p>
          )}
        </Modal>
      )}
      {updates && (
        <Modal title="모드 업데이트" close={() => setUpdates(undefined)}>
          {updates.length ? (
            updates.map((u) => (
              <div className="instance-row" key={u.file}>
                <div>
                  <b>{u.name}</b>
                  <small>{u.latest.name}</small>
                </div>
                <button
                  disabled={disabled}
                  onClick={() =>
                    void run('mods.install', {
                      id: selected.id,
                      provider: u.source.provider,
                      project: u.source.project,
                      version: u.latest.id,
                    })
                  }
                >
                  업데이트
                </button>
              </div>
            ))
          ) : (
            <p>공식 플랫폼에서 더 새로운 호환 버전을 찾지 못했습니다.</p>
          )}
        </Modal>
      )}
    </>
  );
}
function Modpacks() {
  const { s, run, pending } = useApp();
  const items = s.instances.filter((i) => s.packs.includes(i.id));
  const disabled = s.busy || !!s.running || pending;
  return (
    <>
      <div className="toolbar">
        <span className="muted">JAR를 재배포하지 않는 플랫폼 참조 방식</span>
        <div className="button-row">
          <button
            disabled={!s.selected || disabled}
            onClick={() => void run('packs.mark', s.selected)}
          >
            현재 인스턴스를 모드팩으로 등록
          </button>
          <button className="primary" disabled={disabled} onClick={() => void run('packs.import')}>
            ↓ 모드팩 가져오기
          </button>
        </div>
      </div>
      <div className="notice-inline">
        MRPACK 및 CurseForge ZIP을 새 인스턴스로 가져옵니다. 내보내기는 선택한 플랫폼에서 출처가
        확인된 모드만 지원합니다. 설정·월드·개인 파일은 공유 파일에 포함하지 않습니다.
      </div>
      {items.length ? (
        <div className="cards">
          {items.map((i) => (
            <section className="panel instance-card" key={i.id}>
              <Icon name="Modpacks" size={36} />
              <h2>{i.name}</h2>
              <p>
                {i.version} · {i.loader}
              </p>
              <div className="button-row">
                <button
                  disabled={disabled}
                  onClick={() => void run('packs.export', { id: i.id, format: 'mrpack' })}
                >
                  MRPACK 내보내기
                </button>
                <button
                  disabled={disabled}
                  onClick={() => void run('packs.export', { id: i.id, format: 'curseforge' })}
                >
                  CF ZIP
                </button>
              </div>
              <div className="card-tools">
                <button onClick={() => void run('instances.select', i.id)}>선택</button>
                <button disabled={disabled} onClick={() => void run('instances.clone', i.id)}>
                  복제
                </button>
                <button
                  className="danger"
                  disabled={disabled}
                  onClick={() => void run('instances.delete', i.id)}
                >
                  삭제
                </button>
              </div>
            </section>
          ))}
        </div>
      ) : (
        <Empty
          title="나만의 모드팩을 구성하세요"
          body="현재 인스턴스를 등록하거나 MRPACK / CurseForge ZIP을 가져오세요."
        />
      )}
    </>
  );
}
function Upload({ selected }: { selected?: Instance }) {
  const { run, pending, s } = useApp();
  const [project, setProject] = useState('');
  const [name, setName] = useState('');
  const [version, setVersion] = useState('');
  const [changelog, setChangelog] = useState('');
  const [result, setResult] = useState<any>();
  return (
    <div className="twocol">
      <section className="panel">
        <h2>Modrinth 버전 게시</h2>
        <p className="muted">이미 소유한 프로젝트에 새 버전을 업로드합니다.</p>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const r = await run('upload.version', {
              project,
              name,
              version,
              changelog,
              gameVersions: [selected!.version],
              loaders: [selected!.loader],
            });
            if (r) setResult(r);
          }}
        >
          <label>
            프로젝트 ID 또는 슬러그
            <input required value={project} onChange={(e) => setProject(e.target.value)} />
          </label>
          <div className="formgrid">
            <label>
              표시 이름
              <input required value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label>
              버전 번호
              <input required value={version} onChange={(e) => setVersion(e.target.value)} />
            </label>
          </div>
          <label>
            변경 내역
            <textarea value={changelog} onChange={(e) => setChangelog(e.target.value)} rows={5} />
          </label>
          <p className="hint">
            게임 / 로더:{' '}
            {selected ? selected.version + ' / ' + selected.loader : '인스턴스 선택 필요'}. 파일을
            선택한 뒤 권한 확인과 검증 후 게시됩니다.
          </p>
          <button className="primary full" disabled={!selected || pending || s.busy || !!s.running}>
            {pending ? '파일 검증 및 업로드 중…' : '파일 선택 후 게시'}
          </button>
        </form>
        {result && <div className="success">게시 성공 · 버전 ID {result.id}</div>}
      </section>
      <section className="panel">
        <span className="eyebrow">PLATFORM PERMISSIONS</span>
        <h2>게시 권한 안내</h2>
        <p>
          Settings에 Modrinth 개인 토큰을 암호화 저장하세요. 게시 전 로그인 사용자와 프로젝트 팀의
          버전 업로드 권한을 확인합니다.
        </p>
        <p>신규 프로젝트 등록은 공식 웹사이트에서 진행할 수 있습니다.</p>
        <button onClick={() => void run('external', 'https://modrinth.com/dashboard')}>
          Modrinth 대시보드 ↗
        </button>
        <hr />
        <h3>CurseForge 게시</h3>
        <span className="tag warning">지원하지 않음</span>
        <p>
          현재 연동한 CurseForge for Studios API에는 프로젝트 생성·파일 게시 기능이 없습니다. 공식
          작성자 대시보드를 이용하세요.
        </p>
        <button onClick={() => void run('external', 'https://www.curseforge.com')}>
          CurseForge 열기 ↗
        </button>
      </section>
    </div>
  );
}
function Updates() {
  const { run, s, pending } = useApp();
  const [status, setStatus] = useState<any>();
  const disabled = pending || s.busy || !!s.running;
  return (
    <>
      <section className="panel update-hero">
        <div className="update-symbol">
          <Icon name="Update Center" size={58} />
        </div>
        <div>
          <span className="eyebrow">STABLE BY DESIGN</span>
          <h2>
            DKKF Client <span className="cyan">v{s.version}</span>
          </h2>
          <p>
            채널: {s.settings.channel} · 자동 확인{' '}
            {s.settings.autoUpdate ? '활성화 (5분 간격)' : '비활성화'}
          </p>
          <button
            className="primary"
            disabled={disabled}
            onClick={async () => setStatus(await run('update.check'))}
          >
            업데이트 확인
          </button>
        </div>
      </section>
      {status && (
        <section className="panel">
          <h2>
            {
              (
                {
                  unconfigured: '배포 설정 필요',
                  current: '최신 버전입니다',
                  available: '새 버전 ' + status.version,
                  ready: '설치 준비 완료',
                } as any
              )[status.status]
            }
          </h2>
          <p>{status.message || status.notes}</p>
          {status.status === 'available' && (
            <button
              disabled={disabled}
              onClick={async () => setStatus(await run('update.download'))}
            >
              검증 후 다운로드
            </button>
          )}
          {status.status === 'ready' && (
            <button
              className="primary"
              disabled={disabled}
              onClick={() => void run('update.install')}
            >
              런처 종료 후 설치 프로그램 실행
            </button>
          )}
        </section>
      )}
      <div className="twocol">
        <section className="panel">
          <h3>검증된 업데이트</h3>
          <p>
            신뢰한 Ed25519 키로 매니페스트를 검증하고 SHA-256·파일 크기를 검사합니다. 검증 실패 시
            현재 설치 파일을 유지합니다.
          </p>
        </section>
        <section className="panel">
          <h3>지원 범위</h3>
          <p>
            런처 설치 프로그램의 검증·다운로드·실행을 지원합니다. Client Core / HUD 자동 배포 및
            설치 후 자동 롤백은 아직 구현되지 않았습니다.
          </p>
          <span className="tag warning">PARTIAL</span>
        </section>
      </div>
    </>
  );
}
function Settings() {
  const { s, run, pending, toast } = useApp();
  const [v, setV] = useState(s.settings);
  const [secret, setSecret] = useState('');
  const [key, setKey] = useState('curseforge');
  const [saved, setSaved] = useState<any>({});
  useEffect(() => {
    window.dkkf
      .call('settings.secrets')
      .then(setSaved)
      .catch(() => {});
  }, [pending]);
  const change = (k: keyof typeof v, x: any) => setV((a) => ({ ...a, [k]: x }));
  return (
    <>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          await run('settings.save', v);
        }}
      >
        <div className="twocol">
          <section className="panel">
            <h2>게임 환경</h2>
            <label>
              Java 실행 파일
              <div className="inputbutton">
                <input
                  value={v.javaPath}
                  onChange={(e) => change('javaPath', e.target.value)}
                  required
                />
                <button
                  type="button"
                  onClick={async () => {
                    const p = await run<string>('settings.java');
                    if (p) change('javaPath', p);
                  }}
                >
                  찾기
                </button>
                <button
                  type="button"
                  disabled={pending}
                  onClick={async () => {
                    const found = await run<{ path: string; major: number }>('settings.javaAuto');
                    if (found) {
                      change('javaPath', found.path);
                      toast(`Java ${found.major} 발견. 설정 저장을 눌러 적용하세요.`);
                    }
                  }}
                >
                  자동 검색
                </button>
              </div>
            </label>
            <p className="hint">
              Minecraft {target.minecraft} Fabric 기준 Java {target.java} 이상이 필요합니다. 자동
              검색으로 설치된 Java를 찾거나 java.exe 경로를 지정하세요.
            </p>
            <label>
              기본 RAM: {v.ram / 1024} GB
              <input
                type="range"
                min="1024"
                max="32768"
                step="512"
                value={v.ram}
                onChange={(e) => change('ram', Number(e.target.value))}
              />
            </label>
            <div className="formgrid">
              <label>
                해상도 너비
                <input
                  type="number"
                  min="640"
                  max="7680"
                  value={v.width}
                  onChange={(e) => change('width', Number(e.target.value))}
                />
              </label>
              <label>
                해상도 높이
                <input
                  type="number"
                  min="480"
                  max="4320"
                  value={v.height}
                  onChange={(e) => change('height', Number(e.target.value))}
                />
              </label>
            </div>
            <label className="check">
              <input
                type="checkbox"
                checked={v.fullscreen}
                onChange={(e) => change('fullscreen', e.target.checked)}
              />
              전체 화면
            </label>
            <button type="button" onClick={() => void run('settings.data')}>
              게임·다운로드·로그 데이터 폴더 열기 ↗
            </button>
          </section>
          <section className="panel">
            <h2>인증 및 업데이트</h2>
            <label>
              Microsoft Entra Client ID
              <input
                value={v.microsoftClientId}
                onChange={(e) => change('microsoftClientId', e.target.value)}
                placeholder="본인 공개 클라이언트 앱 ID"
              />
            </label>
            <label>
              업데이트 서버 URL
              <input
                type="url"
                value={v.updateUrl}
                onChange={(e) => change('updateUrl', e.target.value)}
                placeholder="https://updates.example.com"
              />
            </label>
            <label>
              Ed25519 공개키 (PEM)
              <textarea
                rows={4}
                value={v.updateKey}
                onChange={(e) => change('updateKey', e.target.value)}
                placeholder="-----BEGIN PUBLIC KEY-----"
              />
            </label>
            <label>
              업데이트 채널
              <select value={v.channel} onChange={(e) => change('channel', e.target.value)}>
                <option value="stable">Stable</option>
                <option value="beta">Beta</option>
              </select>
            </label>
            <label className="check">
              <input
                type="checkbox"
                checked={v.autoUpdate}
                onChange={(e) => change('autoUpdate', e.target.checked)}
              />
              시작 시 및 5분마다 확인·다운로드
            </label>
          </section>
        </div>
        <div className="toolbar right">
          <button className="primary" disabled={pending || s.busy || !!s.running}>
            설정 저장
          </button>
        </div>
      </form>
      <section className="panel">
        <h2>플랫폼 비밀키</h2>
        <p className="muted">
          Windows 계정에 연결된 암호화 저장소에 보관합니다. 저장된 값은 화면으로 다시 보내지
          않습니다.
        </p>
        <div className="formgrid">
          <label>
            플랫폼
            <select
              value={key}
              onChange={(e) => {
                setKey(e.target.value);
                setSecret('');
              }}
            >
              <option value="curseforge">CurseForge API Key</option>
              <option value="modrinth">Modrinth Personal Token</option>
            </select>
          </label>
          <label>
            비밀키 {saved[key] ? '· 저장됨' : '· 설정 안 됨'}
            <input
              type="password"
              autoComplete="off"
              value={secret}
              onChange={(e) => setSecret(e.target.value)}
            />
          </label>
        </div>
        <div className="button-row">
          <button
            disabled={!secret || pending}
            onClick={async () => {
              await run('settings.secret', { key, value: secret });
              setSecret('');
            }}
          >
            암호화 저장
          </button>
          <button
            className="danger"
            disabled={!saved[key] || pending}
            onClick={() => void run('settings.secret', { key, value: '' })}
          >
            저장된 키 삭제
          </button>
        </div>
      </section>
    </>
  );
}
function Account() {
  const { s, run, toast, pending } = useApp();
  const [device, setDevice] = useState<any>();
  const [error, setError] = useState('');
  useEffect(() => {
    if (!device) return;
    let stopped = false;
    let timeout: ReturnType<typeof setTimeout>;
    const end = Date.now() + device.expires * 1000;
    const poll = async () => {
      if (stopped) return;
      if (Date.now() > end) {
        setError('로그인 코드가 만료되었습니다.');
        setDevice(undefined);
        return;
      }
      try {
        const r = await window.dkkf.call('auth.poll');
        if (stopped) return;
        if (!r.pending) {
          await run('state');
          setDevice(undefined);
          toast('Microsoft 계정 연결 완료');
          return;
        }
        timeout = setTimeout(poll, (r.interval || 5) * 1000);
      } catch (e) {
        if (!stopped) {
          setError((e as Error).message);
          setDevice(undefined);
        }
      }
    };
    timeout = setTimeout(poll, (device.interval || 5) * 1000);
    return () => {
      stopped = true;
      clearTimeout(timeout);
    };
  }, [device]);
  return (
    <>
      <section className="panel account-hero">
        <div className="avatar big">
          <Icon name="Account" size={42} />
        </div>
        <div>
          <h2>Microsoft 계정으로 연결하세요.</h2>
          <p>
            Minecraft Java Edition의 실제 이용 권한과 프로필을 확인합니다.
            <br />
            비밀번호는 브라우저의 Microsoft 공식 페이지에서만 입력하세요.
          </p>
          <button
            className="primary"
            disabled={pending || !!device || !!s.running}
            onClick={async () => {
              setError('');
              const d = await run('auth.begin');
              if (d) setDevice(d);
            }}
          >
            ＋ Microsoft 로그인
          </button>
        </div>
      </section>
      {!s.settings.microsoftClientId && (
        <div className="notice-inline warning">
          로그인하려면 Settings에서 본인 Microsoft 앱의 Client ID를 먼저 등록해야 합니다. 공개
          클라이언트 및 Xbox/Minecraft API 승인 설정은 BUILD.md를 확인하세요.
        </div>
      )}
      {error && <p className="error">{error}</p>}
      {device && (
        <section className="panel">
          <h2>브라우저에서 로그인 완료</h2>
          <p>아래 코드를 Microsoft 공식 페이지에 입력하세요.</p>
          <div className="device-code">{device.code}</div>
          <div className="button-row">
            <button className="primary" onClick={() => void run('external', device.url)}>
              Microsoft 인증 페이지 열기 ↗
            </button>
            <button
              onClick={() => {
                setDevice(undefined);
                void run('auth.cancel');
              }}
            >
              취소
            </button>
          </div>
          <p className="muted">
            인증 완료를 기다리고 있습니다. 성공 응답 및 게임 소유권 확인 전까지 계정을 추가하지
            않습니다.
          </p>
        </section>
      )}
      <section className="panel">
        <h2>연결된 계정</h2>
        {s.accounts.length ? (
          s.accounts.map((a) => (
            <div className="instance-row" key={a.id}>
              <div className="avatar">{a.name.slice(0, 1)}</div>
              <div>
                <b>{a.name}</b>
                <small>{a.id}</small>
              </div>
              <button
                disabled={!!s.running || s.activeAccount === a.id}
                onClick={() => void run('auth.select', a.id)}
              >
                {s.activeAccount === a.id ? '사용 중' : '선택'}
              </button>
              <button
                className="danger"
                disabled={!!s.running}
                onClick={() => void run('auth.logout', a.id)}
              >
                로그아웃
              </button>
            </div>
          ))
        ) : (
          <p className="muted">연결된 계정이 없습니다.</p>
        )}
      </section>
    </>
  );
}
createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
